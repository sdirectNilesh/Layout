export const successAction = (statusCode, data, message = 'OK',token) => {
    return { statusCode, data, message ,token}
}

export const failAction = (statusCode, data = null, message = 'Fail',) => {
    return { statusCode, data, message }
}
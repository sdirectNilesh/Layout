export const statusCode = {
    success: 200,
    created: 201,
    badRequest: 400,
    serverError: 500,
    unauthorized: 401,
    conflict: 409,
    forbidden: 403,
    notfound: 404,
    notallowed: 405,
};

export const message = {
    tokenExpired: "Token Expired",
    tokenRequired: "Token Required",
    invalidCredentials: "Invalid Credentials",
    invalidRequest: "Invalid Request",
    forgotEmailSent: 'Please check your email to reset the password.',
    invitationMailSent: 'Invitaion mail sent successfully',
    accountDeactive: 'Your account is inactive. Please contact with SurveyHub support team for more information.',
    passwordResetSuccess: 'Password reset successfull',
    somethingWentWrong: 'Something went wrong.',
    notificationRead: 'Notification marked as read successfully',
    unauthorized: 'You are not authorized to perform this operation',
    subscriptionCancelled: 'Subscription cancelled successfully',
    interestMailSent: 'Interest mail sent successfully',
    dataExpired: (val) => `${val} is expired.`,
    dataAdded: (val) =>`${val} has been added successfully.`,
    dataExist: (val) =>`${val} already exists.`,
    dataNotFound: (val) =>`${val} record not found.`,
    loginSuccess: (val) => `${val} is logged in successfully.`,
    dataChanged: (val) =>`${val} changed successfully.`,
    dataUpdateFailed: (val) => `Failed to update ${val}.`,
    dataUpdated: (val) => `${val} data updated successfully.`,
    dataDeleted: (val) => `${val} data deleted successfully.`,
    dataFetched: (val) =>`${val} data fetched successfully.`,
    accountDeactivation: (val) =>`Account has been ${val} successfully.`
    
}

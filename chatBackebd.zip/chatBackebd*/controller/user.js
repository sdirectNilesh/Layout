
import { message, statusCode } from "../utilities/message";
import { failAction, successAction } from "../utilities/response";
import * as userService from '../service/user'
import jwt from 'jsonwebtoken'
import mongoose from "mongoose";

export const addUser = async (req, res) => {
    let result;
    try {
        result = await userService.AddUser(req.body);
        if (result === 'userAlreadyExist') {
            return res.status(statusCode.notallowed).json(failAction(statusCode.notallowed, result, message.dataExist("User")));
        }
        return res.status(statusCode.created).json(successAction(statusCode.created, result, message.dataAdded("User")));
    } catch (error) {
        console.log("Error @ ", error);
        return res.status(statusCode.serverError).json(failAction(statusCode.serverError, result, error.message));
    }
}

export const login = async (req, res) => {
    let result;
    try {
        result = await userService.Login(req.body);
        if (result === 'invalidCredentials') {
            return res.status(statusCode.unauthorized).json(failAction(statusCode.unauthorized, result, message.invalidCredentials));
        }
        else {
            const token = jwt.sign(JSON.stringify(result), "KeepSmiling")
            return res.status(statusCode.success).json(successAction(statusCode.success, result, message.loginSuccess('User'), token));
        }
    } catch (error) {
       console.log(error)
        return res.status(statusCode.serverError).json(failAction(statusCode.serverError, result, error.message));
    }
};


export const getUserList = async(req,res) => {
    let result;
    try {
        result = await userService.getUserList();
       
            return res.status(statusCode.success).json(successAction(statusCode.success, result, message.loginSuccess('User'), null));
        
    } catch (error) {
       console.log(error)
        return res.status(statusCode.serverError).json(failAction(statusCode.serverError, result, error.message));
    }


}

export const logout = async(req,res) => {
    let result;
    let userId=req.body.userId
    userId=new mongoose.Types.ObjectId(userId)

    console.log("logout", userId)
    try {
        result = await userService.logout(userId);
       
            return res.status(statusCode.success).json(successAction(statusCode.success, result, message.loginSuccess('User'), null));
        
    } catch (error) {
       console.log(error)
        return res.status(statusCode.serverError).json(failAction(statusCode.serverError, result, error.message));
    }
}
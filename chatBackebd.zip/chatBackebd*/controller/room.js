import mongoose from 'mongoose';
import * as roomService from '../service/room'
import { message, statusCode } from '../utilities/message';
import { failAction, successAction } from '../utilities/response';

export const getActiveChat=async(req,res)=>
{
    let result;
    try {
        result = await roomService.getActiveChat(req.userId);
        if(result)
        {
            return res.status(statusCode.success).json(successAction(statusCode.success, result, message.loginSuccess('User'), null));
        }
    
    } catch (error) {
       console.log(error)
        return res.status(statusCode.serverError).json(failAction(statusCode.serverError, result, error.message));
    }
}

export const getIndividualChat=async(req,res)=>
{
    let roomId = req.query.roomId
  // console.log("room controller", req.query)
  roomId = new mongoose.Types.ObjectId(roomId)


  try {

    const result = await roomService.getIndividualChat(roomId)
    // console.log(result)

    return res.status(statusCode.success).json(successAction(statusCode.success,result,null,message.userFound))

  } catch (e) {
    console.log(e);
    return res.status(statusCode.serverError).json(failAction(statusCode.serverError,result,message.userNotFound))

  }
}

export const findRoom=async(req,res)=>
{
  try {

    const result = await roomService.findRoom(req.query)
    // console.log(result)

    return res.status(statusCode.success).json(successAction(statusCode.success,result,null,message.userFound))

  } catch (e) {
    console.log(e);
    return res.status(statusCode.serverError).json(failAction(statusCode.serverError,result,message.userNotFound))

  }
}


export const setUnreadCount = async(req,res) => {
  try {
  let userId = req.body.userId

  userId = new mongoose.Types.ObjectId(userId)
  
    const result = await roomService.setUnreadCount(userId)
    console.log(result)

    return res.status(statusCode.success).json(successAction(statusCode.success,result,null,message.userFound))

  } catch (e) {
    console.log(e);
    return res.status(statusCode.serverError).json(failAction(statusCode.serverError,result,message.userNotFound))

  }
}
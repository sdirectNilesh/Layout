import express from 'express'
import dotenv from 'dotenv'
const app=express()
import cors from 'cors'
require("./db/db.config")();
import http from 'http'
import socketServer from './socket'
const userRoute=require('./route/userRoute')
const roomRoute=require('./route/roomRoute')

app.use(cors())
dotenv.config()
const port=process.env.PORT

app.use(express.json())
app.use(express.urlencoded({extended:true}))



app.use('/',userRoute)
app.use('/',roomRoute)

const server=http.createServer(app)

socketServer(server)

server.listen(port,()=>{console.log(`running on port ${port}`)})
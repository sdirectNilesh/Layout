const express = require("express");
const jwt = require("jsonwebtoken");

exports.authMiddle = (req, res, next) => {
    // console.log("Authorization middleware")
    // console.log("request")   
    const authHeader = req.headers["authorization"];

    // console.log("authHeader", authHeader)
    const token = authHeader.slice(7);
    try {
        const decode = jwt.verify(token, "KeepSmiling");
        // console.log("decode", decode)

        req.userId = decode._id;
        next();
    } catch (error) {
        if (error instanceof jwt.JsonWebTokenError) {

            res.status(401).json({ success: false, message: "Invalid token" });
        } else {

            res.status(500).json({ success: false, message: "Internal server error" });
        }
    }
};
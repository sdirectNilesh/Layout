import mongoose from 'mongoose';
import Room from '../collections/room'
import room from '../collections/room/db.schema'

export const getActiveChat=async(payload)=>
{
    let userId=new mongoose.Types.ObjectId(payload)
    
    const activeChat = await Room.aggregate([
        {
            $match: {
                participants: { $in: [userId] }
            }
        },
        {
            $lookup: {
                from: 'messages',
                localField: "roomId",
                foreignField: "_id",
                as: "message"

            }
        },
        {
            $lookup: {
                from: "users",
                localField: "participants",
                foreignField: "_id",
                as: "participantsInfo"
            }
        },
        {
            $addFields: {
                receiverInfo: {
                    $arrayElemAt: [
                        {
                            $filter: {
                                input: "$participantsInfo",
                                cond: {
                                    $ne: ["$$this._id", userId]
                                }
                            }
                        },
                        0
                    ]
                }
            }
        },
        {
            $project: {
                participantsInfo: 0 
            }
        }

    ]);

    if(activeChat.length)
    {
    return activeChat;
    }
    return null
}


// export const getIndividualChat = async (payload) => {
//     const chats = await Room_Model.aggregate([
//         {
//             $match: {
//                 _id: payload
//             }
//         },
//         {
//             $lookup: {
//                 from: 'messages',
//                 let: { roomId: '$_id' },
//                 pipeline: [
//                     {
//                         $match: {
//                             $expr: { $eq: ['$roomId', { $toObjectId: '$$roomId' }] }
//                         }
//                     },
//                     {
//                         $project: {
//                             _id: 0,
//                             sender: 1,
//                             receiver: 1,
//                             message: 1
//                         }
//                     }
//                 ],
//                 as: 'messages'
//             }
//         },
//         {
//             $unwind: '$messages'
//         },
//         {
//             $lookup: {
//                 from: 'users',
//                 localField: 'messages.sender',
//                 foreignField: '_id',
//                 as: 'messages.senderInfo'
//             }
//         },
//         {
//             $lookup: {
//                 from: 'users',
//                 localField: 'messages.receiver',
//                 foreignField: '_id',
//                 as: 'messages.receiverInfo'
//             }
//         }
//     ]);
//     if (chats.length) {
//         return chats
//     }
//     return null
// }


export const getIndividualChat = async (payload) => {
    const chats = await Room.aggregate([
        {
            $match: {
                _id: payload
            }
        },
        {
            $lookup: {
                from: 'messages',
                let: { roomId: '$_id' },
                pipeline: [
                    {
                        $match: {
                            $expr: { $eq: ['$roomId', '$$roomId' ] }
                        }
                    },
                    {
                        $project: {
                            _id: 1,
                            sender: 1,
                            receiver: 1,
                            message: 1
                        }
                    }
                ],
                as: 'messages'
            }
        },
        {
            $unwind: '$messages'
        },
        {
            $lookup: {
                from: 'users',
                localField: 'messages.sender',
                foreignField: '_id',
                as: 'messages.senderInfo'
            }
        },
        {
            $lookup: {
                from: 'users',
                localField: 'messages.receiver',
                foreignField: '_id',
                as: 'messages.receiverInfo'
            }
        }
    ]);

    if (chats.length) {
        return chats;
    }

    return null;
};


// export const findRoom = async(payload) => {
//     console.log(payload)
//     let room = await Room.findOne({participants:{ '$size' : 2 , '$all':[payload.senderId,payload.receiverId]}})
//     console.log("room",room)
// }

export const findRoom = async (payload) => {
    // console.log(payload);
    try {
      let room = await Room.findOne({
        participants: { $size: 2, $all: [payload.senderId, payload.receiverId] },
      });
    //   console.log("room", room);
      return room; // Assuming you want to return the room
    } catch (error) {
      console.error("Error finding room:", error);
      throw error; // Propagate the error
    }
  };


  export const setUnreadCount = async(payload) => {
    let room = await Room.findByIdAndUpdate({_id: payload},{
        $set:{
            unreadCount: 0
        }
    })
    return room
  }
  
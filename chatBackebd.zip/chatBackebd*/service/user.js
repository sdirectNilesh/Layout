import User from '../collections/user'
import bcrypt from 'bcrypt'

export const AddUser = async (payload) => {
    payload["email"] = payload.email.toLowerCase();
  
    const checkUserExists = await User.findOne({ email: payload.email, isDeleted: false });
  
    if (checkUserExists) {
      return "userAlreadyExist"
    } else {
      
      const hashPass = bcrypt.hashSync(payload.password, 10)
      payload.password = hashPass
      const userData = new User(payload);
      return userData.save();
    }
  };

  export const Login = async (payload) => {
    payload["email"] = payload.email.toLowerCase();
    console.log(payload)
    const checkUserExists = await User.findOne({ email: payload.email, isDeleted: false });
    if (!checkUserExists) {
      return 'invalidCredentials'
    }
    const match = bcrypt.compareSync(payload.password, checkUserExists.password)
    if (!match) {
      return 'invalidCredentials'
    }
  
    return checkUserExists
  }

  export const getUserList = async(payload) => {

    const users=await User.find()
    return users
  }

  export const logout = async(payload) =>{
    
    // console.log("logout",payload)

    const updateObj= await User.findByIdAndUpdate({_id: payload},
      {
        $set :{
          status : false
        }
      })

      return updateObj
  }
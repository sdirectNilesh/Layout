const route = require("express").Router()
import * as roomCtrl from '../controller/room'
import { authMiddle } from '../middleware/tokenVerify'


route.get('/getActiveChat',authMiddle,roomCtrl.getActiveChat)
route.get('/getIndividualChat',authMiddle,roomCtrl.getIndividualChat)
route.get('/findRoom',roomCtrl.findRoom)
route.post('/setUnreadCount',roomCtrl.setUnreadCount)
module.exports=route
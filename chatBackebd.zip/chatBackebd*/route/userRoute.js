const route=require("express").Router()
import * as userCtrl from '../controller/user'

route.post('/signUp',userCtrl.addUser)
route.post('/login',userCtrl.login)
route.get('/getUserList',userCtrl.getUserList)
route.post('/logout',userCtrl.logout)

module.exports=route
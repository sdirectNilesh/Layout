import e from "cors";
import { Server } from "socket.io";
import Room from './collections/room'
import User from './collections/user'
import Message from './collections/message-collection'
let io;


export default (server) => {
  io = new Server(server, {
    cors: {
      origin: "*"
    }
  })


  io.on("connection", (socket) => {
    console.log("-----Socket Connected-----");

    // Handle socket events here

    io.to(socket.id).emit("create_socket", { socketId: socket.id })


    socket.on("createconnection", async (data) => {

      // console.log(data)
      if (data.userId) {
        let userData = await User.findByIdAndUpdate({ _id: data?.userId },
          {
            $set: {
              socketId: data.socketId, status: true
            }
          })
        // console.log("userdata", userData)
      }
    })

    socket.on("message", (async (data) => {
      // console.log("message",data)

      const sender = await User.findOne({ _id: data?.senderId })
      const receiver = await User.findOne({ _id: data?.receiverId })

      let room;
      let lastMsg;

      const roomExist = await Room.findOne({ participants: { "$size": 2, "$all": [sender?._id, receiver?._id] } })
      if (!roomExist) {
        const participants = [sender?.id, receiver?.id]

        const _room = new Room({ participants })
        _room.unreadCount = _room.unreadCount + 1

        console.log("room_Data",_room)
        room = await _room.save()
        if (room) {
          message(data)
        }

      }
      else {
        // console.log("room eXIST",roomExist)
        roomExist.unreadCount = roomExist.unreadCount + 1
        roomExist.save()
        // console.log("room data",roomExist)
        room = roomExist
        message(data)
      }


        // console.log("This is receiver ",receiver)
        // console.log("This is receiver socketid", receiver?.socketId)

        // io.emit("newMessage", data)
        socket.to(receiver?.socketId).emit("newMessage",{data : data})
        // console.log("End of receive")
      

      async function message(data) {

        const newMessage = await Message({ ...data, sender: sender?._id, receiver: receiver?._id, roomId: room?._id })
        const savedMessage = await newMessage.save()
        if (savedMessage) {
          const payload = {
            lastMessage: data?.message,
            lastMessageBy: sender?._id,
            lastMessageDate: new Date()
          }
          const updateRoom = await Room.findByIdAndUpdate({ _id: room?._id }, payload)

          // lastMsg = data?.message
          //  console.log("last message",lastMsg)

        }

      }

    }))


    socket.on("disconnect", () => {
      console.log("User disconnected");
    });
  });

  return io;
};


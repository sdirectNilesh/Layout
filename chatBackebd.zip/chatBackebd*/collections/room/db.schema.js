import mongoose from  'mongoose';


const room = new mongoose.Schema({

    roomId : {
        type : String,
        default: null
    },
    participants : [
        {
            type : mongoose.Schema.Types.ObjectId,
            ref  : 'user'
        }
    ],
    lastMessage : {
        type : String,
        default : null
    },
    lastMessageDate : {
        type : Date,
        default : null
    },
    lastMessageBy : {
        type : String,
        default : null
    },
    isDeleted : {
        type : Boolean,
        default : false
    },
    unreadCount :{
        type : Number,
        default : 0
    }
},
{timestamp : true}
);

export default room
import mongoose from 'mongoose'

const user=mongoose.Schema({
    userName: { 
        type: String,
        default: null
    },
    email: {
        type: String,
        default: null
    },
    password: {
        type: String,
        default: null
    },
    status: {
        type:Boolean,
        default: false, 
        
    },
    socketId:{
        type:String,
        default:null
    },
    isDeleted: {
        type: Boolean,
        default: false
    },
    providerType: {
        type: String,
        enum: ['local', 'google', 'facebook', 'twitter'], // Add other provider types as needed
        default: 'local' // Set a default provider type if necessary
    },
    providerId: {
        type: String
    },

},
{ timestamps: true })


export default user
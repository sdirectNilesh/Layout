import mongoose from "mongoose";
import dbSchema from './db.schema'

export default mongoose.model("user",dbSchema)
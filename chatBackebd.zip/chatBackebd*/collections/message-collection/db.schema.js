import mongoose from "mongoose";

const message = new mongoose.Schema({

    sender : {
        type: mongoose.Schema.Types.ObjectId,
        ref : 'user'
    },
    receiver : {
        type: mongoose.Schema.Types.ObjectId,
        ref : 'user'

    },
    message : {
        type : String,
        default : null
    },
    roomId : {
        type: mongoose.Schema.Types.ObjectId,
        ref : 'room'
    },
    isDeleted : {
        type : Boolean,
        default : false
    }
},
{timestamps : true}
);


export default message
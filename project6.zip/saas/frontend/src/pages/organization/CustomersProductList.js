import React, { useEffect, useState } from 'react'
import { Col, Button, Row, Form, Card, Container } from "react-bootstrap"
import axios from 'axios'
import Table from 'react-bootstrap/Table';
import jwt_decode from "jwt-decode";
import { Link, useNavigate } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';



function OrganizationCustomersProduct() {

    const navigate = useNavigate();
    const [products, setProducts] = useState([]);
    let decode = null;

    if (localStorage.getItem('token')) {
        decode = jwt_decode(localStorage.getItem('token'));
    }



    const fetchCustomersProducts = async () => {
        const { data } = await axios.get(
            `http://localhost:5003/get-customers-product?organizationId=${decode.info.id}`
        );
        const products = data.customer;
        setProducts(products);
        console.log("data: ", data);
    };

    useEffect(() => {
        fetchCustomersProducts();
    }, []);

    const userLogout = () => {
        const token = localStorage.clear();
        console.log("tok: ", token);
        if (!token) {
            navigate("/");
        }
    }
    const deleteProduct = async (id) => {
        try {
          const response = await axios.delete(`http://localhost:5003/delete-product?productId=${id}`,);
          fetchCustomersProducts();
          console.log(response.data)
        } catch (error) {
          console.log(error)
        }
      }
    console.log("products: ", products)
    return (
        <div>
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <a class="navbar-brand" href="#">{decode.info.organization_name} Customers Products </a>
                <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                    <div class="navbar-nav">
                        <h8 class="navbar-brand" href="#">{decode.organization_name}</h8>
                    </div>
                </div>
                <Button className='btn' style={{ marginRight: "1.6%", width: "8%" }} onClick={userLogout}>Logout</Button>
            </nav>
            <br></br>
            <div className='customer-table' style={{ margin: "1%", border: "ridge" }}>
                {products?.length > 0 ?
                    <div>
                        <Table class="table" >
                            <thead>
                                <tr>
                                    <th scope="col">Index</th>
                                    <th scope="col">Customer</th>
                                </tr>
                            </thead>
                            <tbody >
                                {products?.length > 0 && products.map((product, index) => (
                                    <tr>
                                        <th scope="row">{index+1}</th>
                                        <td>{product.customer_name}</td>
                                        <div className='product-table' style={{ width: "100%", border: "ridge" }}>
                                        {product.Nilesh_saas_products?.length > 0 ?
                                        <div>
                                            <Table class="table" >
                                                <thead>
                                                    <tr>
                                                        <th scope="col">Product</th>
                                                        <th scope='col'>Brand</th>
                                                        <th scope='col'>Price</th>
                                                        <th scope='col'>Stock</th>
                                                    </tr>
                                                </thead>
                                                <tbody >
                                                    {product.Nilesh_saas_products?.length > 0 && product.Nilesh_saas_products.map((productlist) => (
                                                        <tr>
                                                            <td>{productlist.product_name}</td>
                                                            <td>{productlist.brand}</td>
                                                            <td>{productlist.price}</td>
                                                            <td>{productlist.stock}</td>
                                                            <td><Button onClick={() => deleteProduct(productlist.id)}>Delete</Button></td>
                                                        </tr>
                                                    ))}
                                                </tbody>
                                            </Table>
                                            </div>
                                            :
                                            <div>Products Not Added Yet</div>
                                                    }
                                        </div>
                                    </tr>
                                ))
                                }
                            </tbody>
                        </Table></div> :
                    <div>NO DATA FOUND</div>
                }
            </div>
        </div>
    )
}

export default OrganizationCustomersProduct;
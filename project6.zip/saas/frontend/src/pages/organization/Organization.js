import React, { useEffect, useState } from 'react'
import { Col, Button, Row, Form, Card, Container } from "react-bootstrap"
import axios from 'axios'
import Table from 'react-bootstrap/Table';
import Dropdown from 'react-bootstrap/Dropdown';
import { ToastContainer, toast } from 'react-toastify';
import jwt_decode from "jwt-decode";
import { Link, useNavigate } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';




function Organization() {

    const [customerList, setCustomerList] = useState([]);
    const [count, setCount] = useState(1);
    const navigate = useNavigate();
    let organization_name = null;
    let decode = null;

    if (localStorage.getItem('token')) {
        decode = jwt_decode(localStorage.getItem('token'));
        organization_name = decode.info.organization_name;
    }

    // Function to check token expiration
    const checkTokenExpiration = () => {
        const token = localStorage.getItem('token');
        if (token) {
            const decodedToken = jwt_decode(token);
            console.log("admin sign in: ", decodedToken)
            if (decodedToken.exp < Date.now() / 1000) {
                // Token is expired, log the user out
                console.log("ghgg", decodedToken.exp);
                userLogout();
            }
        }
    };
    // Set up a timer to periodically check token expiration
    const tokenCheckInterval = setInterval(checkTokenExpiration, 5000); // Check every second

    const fetchAllCustomer = async () => {

        const { data } = await axios.get(
            `http://localhost:5003/get-organizationcustomer?organizationId=${decode.info.id}`
        );
        // const customerList = data.p;
        setCustomerList(data.customer);

    };

    useEffect(() => {
        fetchAllCustomer();
    }, []);

    const userLogout = () => {
        // When user logs out
        clearInterval(tokenCheckInterval); // Clear the timer
        const token = localStorage.clear();
        console.log("tok: ", token);
        if (!token) {
            navigate("/");
        }
    }
    const addCustomer = () => {
        const token = localStorage.getItem('token');
        if (!token) {
            console.log("first:  ", decode);
            return navigate('/');
        } else {
            navigate('/organization/addcustomer');
        }
    }

    const handleRemove = async (id) => {
        try {
            console.log("id: ", id)
            const { data } = await axios.patch(`http://localhost:5003/remove-customer?customerId=${id}`);
            if (data.success === true) {
                toast.success(data.message);
            }
            console.log("data of remove: ", data);
        } catch (error) {
            console.log("Error at error: ", error);
        }
    }

    return (
        <div>
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <a class="navbar-brand" href="#">Customer of {decode.info.organization_name} </a>
                <Dropdown>
                    <Dropdown.Toggle variant="success" id="dropdown-basic" style={{ marginRight: "25px", marginLeft: "-10px" }}>
                        Home
                    </Dropdown.Toggle>
                    <Dropdown.Menu style={{ marginRight: "10px", marginLeft: "-47px", marginTop: "5px" }}>
                        <Dropdown.Item href="/organization">Home</Dropdown.Item>
                        <Dropdown.Item href="/organization/customers-products">{decode.info.organization_name}  Customers Product</Dropdown.Item>
                       
                    </Dropdown.Menu>
                </Dropdown>
                <div class="collapse navbar-collapse" id="navbarNavAltMarkup" >
                    <div className='logout-btn' style={{ marginRight: "1.4%", marginLeft: "-1%", width: "8%" }} >
                        <Button className='btn' onClick={addCustomer}>AddCustomer</Button>
                    </div>
                </div>

                <div className='logout-btn' style={{ marginRight: "1.4%", marginLeft: "-1%", width: "8%" }} >
                    <Button className='btn' onClick={userLogout}>Logout</Button>
                </div>

            </nav>
            <br></br>
            {customerList?.length > 0 ?
               <div>
            <Table class="table" >
                <thead>
                    <tr>
                        <th scope="col">Index</th>
                        <th scope="col">Customer</th>
                        <th scope='col'>Email</th>
                        <th scope='col'>Phone</th>
                    </tr>
                </thead>
                <tbody >
               
             
                    {customerList?.length > 0 && customerList.map((customer, index) => (
                        <tr>
                            <th scope="row">{index+1}</th>
                            <td>{customer.customer_name}</td>
                            <td>{customer.email}</td>
                            <td>{customer.phone}</td>
                            {customer.isActive ? (
                                    <Form.Check // prettier-ignore
                                        type="switch"
                                        id="custom-switch"
                                        checked
                                        onClick={() => { handleRemove(customer.id) }}
                                    />
                                ) : <Form.Check // prettier-ignore
                                    type="switch"
                                    id="custom-switch"
                                    onClick={() => { handleRemove(customer.id) }}
                                />}
                        </tr>
                    ))
                    }
                   
                </tbody>
            </Table> </div>:
                    <div>NO DATA FOUND</div>
                }
            <ToastContainer />
        </div >
    )
}

export default Organization;
import React, { useEffect, useState } from 'react'
import { Col, Button, Row, Form, Card, Container } from "react-bootstrap"
import jwt_decode from "jwt-decode";
import axios from 'axios';
import { Link, useNavigate } from 'react-router-dom';
import { ToastContainer, toast } from 'react-toastify';



function Addcustomer() {

    const navigate = useNavigate();
    const [customer_name, setCustomer_name] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [phone, setPhone] = useState('');
    let organizationId = null;
    let decode = null;
    const backtoHome = () => {
        navigate('/organization')
    }
    if(localStorage.getItem('token')){
        decode = jwt_decode(localStorage.getItem('token'));
        organizationId =  decode.info.id;
    }
    const addCustomer = async (e) => {
        if(!decode){
            navigate('/');
            return;
        }
        e.preventDefault();
        const res = axios
            .post('http://localhost:5003/add-customer',
                {
                    customer_name, email, password, phone, organizationId
                },
                {
                    headers: {
                        Authorization: localStorage.getItem('token'),
                        'Accept': 'application/json',
                        'Content-Type': 'application/json'

                    }
                }
            ).then((response) => {
                if(response.data.success === true){
                    toast.success(response.data.message, {
                        position: "top-right",
                        autoClose: 5000,
                        hideProgressBar: false,
                        closeOnClick: true,
                        pauseOnHover: true,
                        draggable: true,
                        progress: undefined,
                        theme: "light",
                })
                setTimeout(() => {
                    navigate("/organization");
                  }, 1000);
                  console.log("login success");
                }
            }).catch((error) => {
                toast.error(error.response.data.error);
                toast.error(error.response.message);
                console.log("err");
            });
    }
    console.log("organizationId: ", organizationId)
    return (
        <div>
            <nav class="navbar navbar-expand-lg navbar-light bg-light">

                <h3 style={{ marginLeft: "45%" }}>Add Customer</h3 >
                <Button style={{ marginLeft: "35%" }} onClick={backtoHome}>Back</Button>
            </nav>
            <Container>
                <Row className="vh-100 d-flex justify-content-center align-items-center">
                    <Col md={8} lg={6} xs={12}>
                        <div className="border border-3 border-primary"></div>
                        <Card className="shadow">
                            <Card.Body>
                                <div className="mb-3 mt-md-4">
                                    <h2 className="fw-bold mb-2 text-uppercase ">Add Customer</h2>
                                    <div className="mb-3">
                                        <Form method='POST' onSubmit={addCustomer} >
                                            <Form.Group className="mb-3" controlId="formBasicEmail">
                                                <Form.Label className="text-center" aria-required>
                                                    Customer Name
                                                </Form.Label>
                                                <Form.Control type="text" placeholder="Customer_Name" value={customer_name} onChange={(e) => setCustomer_name(e.target.value)} required />
                                            </Form.Group>

                                            <Form.Group
                                                className="mb-3"
                                                controlId="formBasicPassword"
                                            >
                                                <Form.Label aria-required>Customer Email</Form.Label>
                                                <Form.Control type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} required />
                                            </Form.Group>
                                            <Form.Group as={Col} controlId="formGridState">
                                                <Form.Label aria-required>Password</Form.Label>
                                                <Form.Control type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} required />
                                            </Form.Group>
                                            <Form.Group as={Col} controlId="formGridState">
                                                <Form.Label aria-required>Phone</Form.Label>
                                                <Form.Control type="number" placeholder="Phone" value={phone} onChange={(e) => setPhone(e.target.value)} required />
                                            </Form.Group>
                                            <br></br>
                                            <div className="d-grid" mb-3>
                                                <Button variant="primary" type="submit" value="addCustomer" >
                                                    Add
                                                </Button>
                                                <ToastContainer />
                                            </div>
                                        </Form>
                                    </div>
                                </div>
                            </Card.Body>
                        </Card>
                    </Col>
                </Row>
            </Container>
        </div >
    )
}

export default Addcustomer
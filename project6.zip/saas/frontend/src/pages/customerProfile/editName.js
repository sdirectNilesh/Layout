import React from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useFormik } from 'formik';
import { editNameSchema } from '../../schema/schema';
import axios from 'axios';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import jwt_decode from 'jwt-decode';
const token = localStorage.getItem('token');
let decode = null;
let initialValues=null;
if(token){
  decode = jwt_decode(token);
  initialValues = {
    newName: decode.info.customer_name
}
}


function EditName() {
    const navigate = useNavigate();
  
    const { values, touched, errors, handleBlur, handleChange, handleSubmit } = useFormik({
        initialValues: { ...initialValues },
        validationSchema: editNameSchema,
        onSubmit: (async (values) => {
            const customerName = {
                newName: values.newName
            }
            try {
                    const { data } = await axios.post(`http://localhost:5003/update-name?customerId=${decode.info.id}`, customerName);
                    console.log("editted name data: ", data);
                    if (data.success) {
                        toast.success("Name has been updated", {
                            position: "top-right",
                            autoClose: 5000,
                            hideProgressBar: false,
                            closeOnClick: true,
                            pauseOnHover: true,
                            draggable: true,
                            progress: undefined,
                            theme: "light",
                        })
                        setTimeout(() => {
                              localStorage.clear('token')
                              navigate("/");
                        }, 1000);
                    }
            } catch (error) {
                console.log("Axios Error at EditName: ", error);
                toast.error(error.response.data.error);
            }
        })
    })
    return (
        <>
            
            <div className='add-address' style={{ width: "50%", marginLeft: "30%", marginTop: "1%", border: "ridge  ", borderRadius: "5%", boxShadow: " rgba(0, 0, 0, 0.35) 0px 5px 15px" }}>
                <div style={{ fontWeight: "300", marginRight: "40%", marginTop: "3%", marginBottom: "4%" }}>
                    <h2 style={{ fontWeight: "bold" }}>Edit Your Name</h2 >
                </div>
                <form style={{ marginLeft: "4%" }} onSubmit={handleSubmit}>

                    <div class="form-outline mb-1">
                        <label class="form-label" for="form6Example4" style={{ marginLeft: "-75%", fontWeight: "bold" }}>New Name</label>
                        <input type="text" id="form6Example4" class="form-control"  style={{ border: "ridge  ", borderRadius: "5%", width: "95% " }} name='newName' value={values.newName} onBlur={handleBlur} onChange={handleChange} />
                        {errors.newName && touched.newName ? (
                            <p className='form-error' style={{ color: "blue" }}>{errors.newName}</p>
                        ) : null}
                    </div>

                    <button type="submit" class="btn btn-primary btn-block mb-3" style={{ width: "25%", marginLeft: "2%" }}>Submit</button>
                    <ToastContainer />
                </form>
            </div>
        </>
    )
}

export default EditName
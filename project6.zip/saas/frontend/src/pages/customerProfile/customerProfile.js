import React, { useEffect, useState } from 'react'
import {
    MDBCard,
    MDBCardBody,
    MDBCardImage,
    MDBBtn,
    MDBRipple,
    MDBRow
} from 'mdb-react-ui-kit';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import jwt_decode from 'jwt-decode'


function CustomerInfo() {
    const navigate = useNavigate();
    const token = localStorage.getItem('token');
    let decode = null;
    if (token) {
        decode = jwt_decode(token);
    }

  
    const handleName = () => {
        navigate('/customer/edit-Name');
    }

    const handlePassword = () => {
        navigate('/customer/edit-password');
    }
    const backtoHome = () => {
        navigate('/customer')
    }
    return (
        <div>
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <a class="navbar-brand" href="#">Customer {decode.info.customer_name}</a>
                <MDBBtn style={{ marginLeft: "78%" }} onClick={backtoHome}>Back</MDBBtn>
            </nav>
            <div className='add-address' style={{ width: "50%", marginLeft: "30%", marginTop: "1%", marginBottom: "1%", border: "ridge  ", borderRadius: "5%", boxShadow: " rgba(0, 0, 0, 0.35) 0px 5px 15px", height: "55vh" }}>
                <div style={{ fontWeight: "300", marginRight: "45%", marginTop: "3%", marginBottom: "4%" }}>
                    <h2 style={{ fontWeight: "bold" }}>Login & Security</h2 >
                </div>
                <MDBRow>
                <MDBCard style={{ width: "80%", marginBottom: "0%", marginTop: "0.1%", marginLeft: "1%", marginLeft: "10%", display: "inline-flex", cursor: "pointer", height: "12vh", position: "relative" }}>
                        <MDBCardBody style={{ alignItem: "flex-start", position: "absolute" }}>
                            <p style={{ marginLeft: "-20%" }}>Email: {decode.info.email}</p>
                        </MDBCardBody>
                       
                    </MDBCard>
                    <MDBCard style={{ width: "80%", marginBottom: "0%", marginTop: "0.1%", marginLeft: "1%", marginLeft: "10%", display: "inline-flex", cursor: "pointer", height: "12vh", position: "relative" }}>
                        <MDBCardBody style={{ alignItem: "flex-start", position: "absolute" }}>
                            <p style={{ marginLeft: "-35%" }}><span>Name: </span>{decode.info.customer_name}</p>

                        </MDBCardBody>
                        <MDBBtn onClick={handleName} style={{ marginTop: "5%", marginLeft: "80%", width: "20%" }}>Edit</MDBBtn>
                    </MDBCard>
                   
                    <MDBCard style={{ width: "80%", marginBottom: "0%", marginTop: "0.1%", marginLeft: "1%", marginLeft: "10%", display: "inline-flex", cursor: "pointer", height: "12vh", position: "relative" }}>
                        <MDBCardBody style={{ alignItem: "flex-start", position: "absolute" }}>
                            <p style={{ marginLeft: "-37%" }}>Password: ******</p>
                        </MDBCardBody>
                        <MDBBtn onClick={handlePassword} style={{ marginTop: "5%", marginLeft: "80%", width: "20%" }}>Edit</MDBBtn>
                    </MDBCard>
                </MDBRow>
            </div>
        </div>
    )
}

export default CustomerInfo
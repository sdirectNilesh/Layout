import React from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useFormik } from 'formik';
import { customerPasswordSchema } from '../../schema/schema';
import axios from 'axios';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import jwt_decode from 'jwt-decode';
import {
    MDBBtn
} from 'mdb-react-ui-kit';


const initialValues = {
    currentPassword: "",
    newPassword: "",
    confirmPassword: ""
}
function EditPassword() {
    const navigate = useNavigate();
    let token = localStorage.getItem('token');
    let decode = null;
    if(token){
         decode = jwt_decode(token);
    }
    console.log("add decode: ", decode.id)
    const { values, touched, errors, handleBlur, handleChange, handleSubmit } = useFormik({
        initialValues: { ...initialValues },
        validationSchema: customerPasswordSchema,
        onSubmit: (async (values) => {
            const customerPassword = {
                currentPassword: values.currentPassword,
                newPassword: values.newPassword,
                confirmPassword: values.confirmPassword
            }
            try {
                if (values.newPassword === values.confirmPassword) {
                    const { data } = await axios.post(`http://localhost:5003/update-password?customerId=${decode.info.id}`, customerPassword);
                    console.log("password data: ", data);
                    if (data.success) {
                        toast.success("Password has been updated", {
                            position: "top-right",
                            autoClose: 5000,
                            hideProgressBar: false,
                            closeOnClick: true,
                            pauseOnHover: true,
                            draggable: true,
                            progress: undefined,
                            theme: "light",
                        })
                        setTimeout(() => {
                            localStorage.clear('token');
                            navigate("/");
                        }, 1000);
                    }
                }
                else{
                    toast.success("New Password and Confirm Passwor is not matching")
                }
            } catch (error) {
                console.log("Axios Error at EditPassword: ", error);
                toast.error(error.response.data.error);
            }
        })
    })

    const backtoHome = () => {
        navigate('/customer')
    }
    return (
        <>
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <a class="navbar-brand" href="#">Customer {decode.info.customer_name}</a>
                <MDBBtn style={{ marginLeft: "78%" }} onClick={backtoHome}>Back</MDBBtn>
            </nav>
            <div className='add-address' style={{ width: "50%", marginLeft: "30%", marginTop: "1%", border: "ridge  ", borderRadius: "5%", boxShadow: " rgba(0, 0, 0, 0.35) 0px 5px 15px" }}>
                <div style={{ fontWeight: "300", marginRight: "45%", marginTop: "3%", marginBottom: "4%" }}>
                    <h2 style={{ fontWeight: "bold" }}>Update Password</h2 >
                </div>
                <form style={{ marginLeft: "4%" }} onSubmit={handleSubmit}>

                    <div class="form-outline mb-1">
                        <label class="form-label" for="form6Example3" style={{ marginLeft: "-73%", fontWeight: "bold" }}>Current Password</label>
                        <input type="password" id="form6Example3" class="form-control" n style={{ border: "ridge  ", borderRadius: "5%", width: "95% " }} name='currentPassword' value={values.currentPassword} onBlur={handleBlur} onChange={handleChange} />
                        {errors.currentPassword && touched.currentPassword ? (
                            <p className='form-error' style={{ color: "blue" }}>{errors.currentPassword}</p>
                        ) : null}
                    </div>

                    <div class="form-outline mb-1">
                        <label class="form-label" for="form6Example4" style={{ marginLeft: "-75%", fontWeight: "bold" }}>New Password</label>
                        <input type="password" id="form6Example4" class="form-control" n style={{ border: "ridge  ", borderRadius: "5%", width: "95% " }} name='newPassword' value={values.newPassword} onBlur={handleBlur} onChange={handleChange} />
                        {errors.newPassword && touched.newPassword ? (
                            <p className='form-error' style={{ color: "blue" }}>{errors.newPassword}</p>
                        ) : null}
                    </div>

                    <div class="form-outline mb-1">
                        <label class="form-label" for="form6Example5" style={{ marginLeft: "-70%", fontWeight: "bold" }}>Confirm Password</label>
                        <input type="password" id="form6Example5" class="form-control" style={{ border: "ridge  ", borderRadius: "5%", width: "95% " }} name='confirmPassword' value={values.confirmPassword} onBlur={handleBlur} onChange={handleChange} />
                        {errors.confirmPassword && touched.confirmPassword ? (
                            <p className='form-error' style={{ color: "blue" }}>{errors.confirmPassword}</p>
                        ) : null}
                    </div>

                    <button type="submit" class="btn btn-primary btn-block mb-3" style={{ width: "25%", marginLeft: "2%" }}>Submit</button>
                    <ToastContainer />
                </form>
            </div>
        </>
    )
}

export default EditPassword
import React from 'react'
import { Link, useNavigate } from 'react-router-dom'
import axios from 'axios';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { loginSchema } from '../schema/schema';
import { useFormik } from 'formik';
import { Button } from 'react-bootstrap';
import '../App.css'

const initialValues = {
  name: "",
  email: "",
  password: "",
  loginType:""
}


function Login() {

  const navigate = useNavigate();
  const { values, errors, touched, handleSubmit, handleBlur, handleChange } = useFormik({
    initialValues: initialValues,
    validationSchema: loginSchema,
    onSubmit: ((values) => {
      const user = {
        email: values.email,
        password: values.password
      }
      if(values.loginType===""){
        toast.error("Please select Your role")
      }
      console.log(values.loginType);
      if(values.loginType==="admin"){
        axios.post("http://localhost:5003/signin-admin", user)
        .then((response) => {
          console.log("response1: ", response)
          if (response.data.success === true) {
            localStorage.setItem('token', response.data.token);
            toast.success("Log in success", {
              position: "top-right",
              autoClose: 5000,
              hideProgressBar: false,
              closeOnClick: true,
              pauseOnHover: true,
              draggable: true,
              progress: undefined,
              theme: "light",
            })
            // alert(response.data.message);
            setTimeout(() => {
              navigate("/admin");
            }, 1000);
            console.log("login success");
          } 
          else{
            toast.error("Please provide a valid credentials")
          }
        })
        .catch((error) => {
          toast.error(error.response.data.message);
          toast.error(error.response.data);
          console.log("error log: ", error)
        })
      } 
      else if(values.loginType==="organization"){
        axios.post("http://localhost:5003/signin-organization", user)
        .then((response) => {
          console.log("response1: ", response)
          if (response.data.success === true) {
            localStorage.setItem('token', response.data.token);
            toast.success("Log in success", {
              position: "top-right",
              autoClose: 5000,
              hideProgressBar: false,
              closeOnClick: true,
              pauseOnHover: true,
              draggable: true,
              progress: undefined,
              theme: "light",
            })
            // alert(response.data.message);
            setTimeout(() => {
              navigate("/organization");
            }, 1000);
            console.log("login success");
          }
        })
        .catch((error) => {
          toast.error(error.response.data.message);
          console.log("error log: ", error)
        })
      }
      else if(values.loginType==='customer') {
        axios.post("http://localhost:5003/signin-customer", user)
        .then((response) => {
          console.log("response1: ", response)
          if (response.data.success === true) {
            localStorage.setItem('token', response.data.token);
            toast.success("Log in success", {
              position: "top-right",
              autoClose: 5000,
              hideProgressBar: false,
              closeOnClick: true,
              pauseOnHover: true,
              draggable: true,
              progress: undefined,
              theme: "light",
            })
            // alert(response.data.message);
            setTimeout(() => {
              navigate("/customer");
            }, 1000);
            console.log("login success");
          }
        })
        .catch((error) => {
          toast.error(error.response.data.message);
          console.log("error log: ", error)
        })
      }
    })
  }) 





  return (
    <div className='login'  style={{display:"flex"}}>
      <div className='leftComponent' style={{ width: "40%", position: "fixed", marginLeft: "-20px", maxHeight: "100vh" }}>
        <img src='https://img.freepik.com/free-vector/family-logo-collection_23-2148545998.jpg?w=740&t=st=1693463008~exp=1693463608~hmac=e01e321818217f464a3ae954c056fa476447cb11e66608ccf788cb46cf2a143a'></img>
      </div>
      <div className='rightComponent'style={{ width: "60%", position: "relative", marginLeft: "620px", maxHeight: "100vh" }}>
        <div className='innerRightcomp' style={{marginLeft:"10%", justifyContent:"space-between"}}>
        <Button variant="light" style={{marginTop:"30px", height:"20vh", width:"20%"}} type="button" name="loginType" value="admin" onClick={handleChange} >Admin</Button>{' '}
        <Button variant="light" style={{marginTop:"30px", height:"20vh", width:"20%"}}type="button" name="loginType" value="organization" onClick={handleChange}>Organization</Button>{' '}
        <Button variant="light" style={{marginTop:"30px", height:"20vh", width:"20%"}} type="button" name="loginType" value="customer" onClick={handleChange}>Customer</Button>{' '}
        </div>
        <section class="vh-110" style={{marginLeft:"10%"}}>
          <div class="container py-5 h-80">
            <div class="row d-flex justify-content-center align-items-center h-0">
              <div class="col-10 col-md-8 col-lg-10 col-xl-9">
                <div class="card shadow-2-strong" style={{ border: "1rem" }}>
                  <div class="card-body p-4 vh-90 text-center">

                    <h3 class="mb-3">Sign in</h3>

                    <div class="text-center">
                      <img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-login-form/lotus.webp"
                        style={{ width: "185px" }} alt="logo" />

                    </div>

                    <form onSubmit={handleSubmit}>
                      <div class="form-outline mb-4">
                        <input type="email" name="email" id="typeEmailX-2" class="form-control form-control-lg" onBlur={handleBlur} value={values.email} onChange={handleChange} />
                        <label class="form-label" for="typeEmailX-2">Email</label>
                        {errors.email && touched.email ? (
                          <p className='form-error' style={{ color: "blue" }}>{errors.email}</p>
                        ) : null}
                      </div>
                      <div class="form-outline mb-4">
                        <input type="password" name="password" id="typePasswordX-2" class="form-control form-control-lg" onBlur={handleBlur} value={values.password} onChange={handleChange} />
                        <label class="form-label" for="typePasswordX-2">Password</label>
                        {errors.password && touched.password ? (
                          <p className='form-error' style={{ color: "blue" }}>{errors.password}</p>
                        ) : null}
                      </div>

                      <button class="btn btn-primary btn-lg btn-block mb-3" type="submit">Login</button>
                      <ToastContainer />

                      <div class="d-flex align-items-center justify-content-center pb-4">
                        <p class="mt-10px mb-0 me-2">Don't have an account?</p>
                        <Link to='/signup'>Create new</Link>
                      </div> <br />

                      <div class="d-flex align-items-center justify-content-center pb-4">
                        <p class="mt-10px mb-0 me-2">Don't have an account?</p>
                        <Link to='/reset-organization'>Reset Password</Link>
                      </div> 
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  )
}

export default Login
import React, { useState } from 'react'
import axios from "axios";
import { Link, useNavigate } from 'react-router-dom'
import 'react-toastify/dist/ReactToastify.css';
import { ToastContainer, toast } from 'react-toastify';

function ResetOrganization() {
    const navigate = useNavigate();
    const [email, setEmail] = useState('')

    const resetLink = async (e) =>{
        e.preventDefault();
        try {
            const {data} = await axios.post(`http://localhost:5003/forgetPassCustomer`, {email: email})
            console.log("Data: ", data)
            if (data.success === true) {
                toast.success(data.message, {
                  position: "top-right",
                  autoClose: 5000,
                  hideProgressBar: false,
                  closeOnClick: true,
                  pauseOnHover: true,
                  draggable: true,
                  progress: undefined,
                  theme: "light",
                })
              }
            }
            catch (error){
                console.log("Error at reset: ", error)
                toast.error(error.response.data.message);
            }
    }

    return (
        <div className='reset-form' style={{borderBox:"10px 10px 5px 12px lightblue", width:"50%", height:"200px", border:"ridge", margin:"25%", marginTop:"5%"}}>
            <h3>Reset Customer <span style={{color: "blue"}}>Password</span></h3> <br />
            <form onSubmit={resetLink}>
                <div class="form-group">
                    <label for="exampleInputEmail1">Email address</label>
                    <input type="email" class="form-control" id="exampleInputEmail1" 
                    aria-describedby="emailHelp" placeholder="Enter email" value={email} onChange={(e) => {setEmail(e.target.value)}}/>
                </div>
                <button type="submit" class="btn btn-primary" style={{marginTop:"3%"}}>Send-mail</button>
                <ToastContainer />
            </form>
        </div>
    )
}

export default ResetOrganization
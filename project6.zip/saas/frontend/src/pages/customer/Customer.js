import React, { useEffect, useState } from 'react'
import { Col, Button, Row, Form, Card, Container, Nav } from "react-bootstrap"
import axios from 'axios'
import Table from 'react-bootstrap/Table';
import jwt_decode from "jwt-decode";
import { Link, useNavigate } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';



function Customer() {

  const navigate = useNavigate();
  const decode = jwt_decode(localStorage.getItem('token'));
  const [userId, setUserId] = useState(decode.userId);
  const [products, setProducts] = useState([]);
  const [search, setSearch] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [productId, setProductId] = useState(null);

  // Function to check token expiration
  const checkTokenExpiration = () => {
    const token = localStorage.getItem('token');
    if (token) {
      const decodedToken = jwt_decode(token);
      console.log("admin sign in: ", decodedToken)
      if (decodedToken.exp < Date.now() / 1000) {
        // Token is expired, log the user out
        console.log("ghgg", decodedToken.exp);
        userLogout();
      }
    }
  };
  // Set up a timer to periodically check token expiration
  const tokenCheckInterval = setInterval(checkTokenExpiration, 5000); // Check every second

  const fetchProducts = async () => {
    const decode = jwt_decode(localStorage.getItem('token'));
    console.log(decode);
    const { data } = await axios.get(
      `http://localhost:5003/get-product?customerId=${decode.info.id}`
    );
    const products = data.product;
    setProducts(products);
    console.log("data: ", data);
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  const userLogout = () => {
    // When user logs out
    clearInterval(tokenCheckInterval); // Clear the timer
    const token = localStorage.clear();
    console.log("tok: ", token);
    if (!token) {
      navigate("/");
    }
  }
  const deleteProduct = async (id) => {
    try {
      const response = await axios.delete(`http://localhost:5003/delete-product?productId=${id}`,);
      fetchProducts();
      console.log(response.data)
    } catch (error) {
      console.log(error)
    }
  }
  const addProduct = () => {
    const token = localStorage.getItem('token');
    if (!token) {
      console.log("first:  ", decode);
      return navigate('/');
    } else {
      navigate('/customer/addproduct');
    }
  }

  return (
    <div>
      <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="#">Customer {decode.info.customer_name}</a>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
          <div class="navbar-nav">
            <h8 class="navbar-brand" href="#">{decode.customer_name}</h8>
          </div>
        </div>

        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
          <div className='logout-btn' style={{ marginRight: "1.4%", marginLeft: "-80%", width: "8%" }} >
            <Button className='btn' onClick={addProduct}>AddProduct</Button>
          </div>
        </div>
        <div className='user-profile' style={{ marginRight: "3%" }}>
          <Nav.Link href='/customer/customer-profile' style={{ marginRight: "3%" }}><img height='32' src='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSKU9Vh0YWdZ3_vDCh054gaovr_B-IH_dxWfYqcoKkmf3ISP1NzCAud&s=0' /></Nav.Link>
        </div>
        <Button className='btn' style={{ marginRight: "1.6%", width: "8%" }} onClick={userLogout}>Logout</Button>
      </nav>
      <br></br>
      <Table class="table" >
        <thead>
          <tr>
            <th scope="col">Index</th>
            <th scope="col">Product</th>
            <th scope='col'>Brand</th>
            <th scope='col'>Price</th>
            <th scope='col'>Stock</th>
          </tr>
        </thead>
        <tbody >
          {products?.length > 0 && products.map((product,index) => (

            <tr>
              <th scope="row">{index+1}</th>
              <td>{product.product_name}</td>
              <td>{product.brand}</td>
              <td>{product.price}</td>
              <td>{product.stock}</td>
              <td><Button onClick={() => deleteProduct(product.id)}>Delete</Button></td>
            </tr>

          ))
          }
        </tbody>
      </Table>
    </div>
  )
}

export default Customer;
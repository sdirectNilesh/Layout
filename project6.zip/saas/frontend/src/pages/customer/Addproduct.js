import React, { useEffect, useState } from 'react'
import { Col, Button, Row, Form, Card, Container } from "react-bootstrap"
import jwt_decode from "jwt-decode";
import axios from 'axios';
import { Link, useNavigate } from 'react-router-dom';
import { ToastContainer, toast } from 'react-toastify';



function Addproduct() {

    const navigate = useNavigate();
    const decode = jwt_decode(localStorage.getItem('token'));
    const [product_name, setProduct_name] = useState('');
    const [price, setPrice] = useState('');
    const [brand, setBrand] = useState('');
    const [stock, setStock] = useState('');
    const backtoHome = () => {
        navigate('/customer')
    }

    const addProduct = async (e) => {
        e.preventDefault();
        const res = axios
            .post(`http://localhost:5003/add-product?customerId=${decode.info.id}`,
                {
                    product_name, price, brand, stock
                },
                {
                    headers: {
                        Authorization: localStorage.getItem('token'),
                        'Accept': 'application/json',
                        'Content-Type': 'application/json'

                    }
                }
            ).then((response) => {
                if(response.data.success === true){
                    console.log("addproduct: ", response)
                    toast.success(response.data.messsage, {
                        position: "top-right",
                        autoClose: 5000,
                        hideProgressBar: false,
                        closeOnClick: true,
                        pauseOnHover: true,
                        draggable: true,
                        progress: undefined,
                        theme: "light",
                })
                setTimeout(() => {
                    navigate("/customer");
                  }, 1000);
                  console.log("login success");
                }
            }).catch((error) => {
                toast.error(error.response.data.messsage);
                console.log("err", error);
            });
    }
    console.log("customerId: ", decode.info.id)
    return (
        <div>
            <nav class="navbar navbar-expand-lg navbar-light bg-light">

                <h3 style={{ marginLeft: "45%" }}>Add Product</h3 >
                <Button style={{ marginLeft: "35%" }} onClick={backtoHome}>Back</Button>
            </nav>
            <Container>
                <Row className="vh-100 d-flex justify-content-center align-items-center">
                    <Col md={8} lg={6} xs={12}>
                        <div className="border border-3 border-primary"></div>
                        <Card className="shadow">
                            <Card.Body>
                                <div className="mb-3 mt-md-4">
                                    <h2 className="fw-bold mb-2 text-uppercase ">Add Product</h2>
                                    <div className="mb-3">
                                        <Form method='POST' onSubmit={addProduct} >
                                            <Form.Group className="mb-3" controlId="formBasicEmail">
                                                <Form.Label className="text-center" aria-required>
                                                    Product Name
                                                </Form.Label>
                                                <Form.Control type="string" placeholder="Product_Name" value={product_name} onChange={(e) => setProduct_name(e.target.value)} required />
                                            </Form.Group>

                                            <Form.Group
                                                className="mb-3"
                                                controlId="formBasicPassword"
                                            >
                                                <Form.Label aria-required>Product Price</Form.Label>
                                                <Form.Control type="integer" placeholder="Price" value={price} onChange={(e) => setPrice(e.target.value)} required />
                                            </Form.Group>
                                            <Form.Group as={Col} controlId="formGridState">
                                                <Form.Label aria-required>Brand</Form.Label>
                                                <Form.Control type="string" placeholder="Brand" value={brand} onChange={(e) => setBrand(e.target.value)} required />
                                            </Form.Group>
                                            <Form.Group as={Col} controlId="formGridState">
                                                <Form.Label aria-required>Stock</Form.Label>
                                                <Form.Control type="integer" placeholder="Stock" value={stock} onChange={(e) => setStock(e.target.value)} required />
                                            </Form.Group>
                                            <br></br>
                                            <div className="d-grid" mb-3>
                                                <Button variant="primary" type="submit" value="addCustomer" >
                                                    Add
                                                </Button>
                                                <ToastContainer />
                                            </div>
                                        </Form>
                                    </div>
                                </div>
                            </Card.Body>
                        </Card>
                    </Col>
                </Row>
            </Container>
        </div >
    )
}

export default Addproduct
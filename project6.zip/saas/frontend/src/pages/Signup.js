import React from 'react'
import { useState, useEffect } from 'react'
import { Link, useNavigate } from "react-router-dom";
import { ToastContainer, toast } from 'react-toastify';
import axios from 'axios';
import { useFormik } from 'formik';
import { sigupSchema } from '../schema/schema';
import { Col, Button, Row, Form, Card, Container } from "react-bootstrap"


const initialValues = {
  organization_name: "",
  email: "",
  password: "",
  subscriptionId: ""
}

function Signup() {
  const navigate = useNavigate();
  const [subscriptionList, setSubcriptionList] = useState([]);

  const { values, errors, touched, handleSubmit, handleBlur, handleChange } = useFormik({
    initialValues: initialValues,
    validationSchema: sigupSchema,
    onSubmit: ((values) => {
      const user = {
        organization_name: values.organization_name,
        email: values.email,
        password: values.password,
        subscriptionId: values.subscriptionId
      }
      axios.post("http://localhost:5003/add-organization", user)
        .then((response) => {
          if (response.data.success === true) {
            toast.success(response.data.message, {
              position: "top-right",
              autoClose: 5000,
              hideProgressBar: false,
              closeOnClick: true,
              pauseOnHover: true,
              draggable: true,
              progress: undefined,
              theme: "light",
            })
            setTimeout(() => {
              navigate("/");
            }, 1000);
          }
          else {
            toast.error(response.data.message)
          }
        })
        .catch((error) => {
          toast.error(error.response.data.message);
          navigate('/signup');
          console.log(error)
        })
    })
  })


  const fetchAllSubscription = async () => {
    try {
      const data = await axios.get(`http://localhost:5003/get-active-subscription`);
      console.log(data.data.getActiveSubscription)
      setSubcriptionList(data.data.getActiveSubscription);
    } catch (error) {
      console.log("Error at fetchAllSuscription: ", error);
    }
  }
  useEffect(() => {
    fetchAllSubscription();
  }, []);
  console.log("subscription: ", subscriptionList)

  console.log({ values })

  return (
    <div className='signup' style={{ display: "flex" }}>
      <div className='leftComponent' style={{ width: "40%", position: "fixed", marginLeft: "-20px", maxHeight: "100vh" }}>
        <img src='https://img.freepik.com/free-vector/family-logo-collection_23-2148545998.jpg?w=740&t=st=1693463008~exp=1693463608~hmac=e01e321818217f464a3ae954c056fa476447cb11e66608ccf788cb46cf2a143a'></img>
      </div>
      <div className='rightComponent' style={{ width: "60%", position: "relative", marginLeft: "620px", maxHeight: "100vh" }}>
        <div className='innerRightcomp' style={{ marginLeft: "10%", justifyContent: "space-between" }}>
          <Button variant="light" style={{ marginTop: "30px", height: "20vh", width: "40%" }}>Organization</Button>{' '}
        </div>
        <section class="vh-110" style={{ marginLeft: "10%" }}>
          <div class="container py-5 h-80">
            <div class="row d-flex justify-content-center align-items-center h-0">
              <div class="col-10 col-md-8 col-lg-10 col-xl-9">
                <div class="card shadow-2-strong" style={{ border: "1rem" }}>
                  <div class="card-body p-4 vh-90 text-center">

                    <h3 class="mb-3">Register</h3>

                    <div class="text-center">
                      <img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-login-form/lotus.webp"
                        style={{ width: "185px" }} alt="logo" />

                    </div>
                    <form onSubmit={handleSubmit} >
                      <div class="form-outline mb-4">
                        <input type="string" name="organization_name" id="typeEmailX-2" class="form-control form-control-lg" onBlur={handleBlur} value={values.organization_name} onChange={handleChange} />
                        <label class="form-label" for="typeEmailX-2">Name</label>
                        {errors.organization_name && touched.organization_name ? (
                          <p className='form-error' style={{ color: "blue" }}>{errors.organization_name}</p>
                        ) : null}

                      </div>


                      <div class="form-outline mb-4">
                        <input type="email" name="email" id="typeEmailX-2" class="form-control form-control-lg" onBlur={handleBlur} value={values.email} onChange={handleChange} />
                        <label class="form-label" for="typeEmailX-2">Email</label>
                        {errors.email && touched.email ? (
                          <p className='form-error' style={{ color: "blue" }}>{errors.email}</p>
                        ) : null}
                      </div>

                      <div class="form-outline mb-4">
                        <input type="password" name="password" id="typePasswordX-2" class="form-control form-control-lg" onBlur={handleBlur} value={values.password} onChange={handleChange} />
                        <label class="form-label" for="typePasswordX-2">Password</label>
                        {errors.password && touched.password ? (
                          <p className='form-error' style={{ color: "blue" }}>{errors.password}</p>
                        ) : null}
                      </div>
                      <div>
                      <Form.Group as={Col} controlId="formGridState">
                        <Form.Label>Category</Form.Label>
                        <Form.Select defaultValue="" placeholder="Subscription" name="subscriptionId" onChange={handleChange} required>
                          {subscriptionList?.length > 0 && subscriptionList.map((subscription) => (
                            <option type="string" id="subscriptionId" class="form-control form-control-lg" onBlur={handleBlur} value={subscription.id} >{subscription.subcriptionName}</option>
                          ))}
                          {errors.subscriptionId && touched.subscriptionId ? (
                            <p className='form-error' style={{ color: "blue" }}>{errors.subscriptionId}</p>
                          ) : null}
                        </Form.Select>
                      </Form.Group>
                      </div>
                      <br></br>
                      <button class="btn btn-primary btn-lg btn-block mb-3" type="submit" name="signup" value="register" >Signup</button>
                      <ToastContainer />
                      <div class="d-flex align-items-center justify-content-center pb-4">
                        <p class="mt-10px mb-0 me-2">Have an account</p>
                        <Link to='/'>Login</Link>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  )
}

export default Signup
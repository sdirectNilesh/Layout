import React, { useState } from 'react'
import axios from "axios"
import { useNavigate, useParams } from "react-router-dom"
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

function ResetPassword() {

    const navigate = useNavigate();
    const params = useParams();
    const token = params.resetToken
    console.log({token})

    const [email, setEmail] = useState('')
    const [password, setPassword] = useState('')

    const updatePassword = async (e) => {
        e.preventDefault()

        try {
            const result = await axios.post(`http://localhost:5003/passwordUpdateCustomer/${token}`,
                {
                    email: email,
                    password: password
                })
                console.log("result: ", result);
                if (result.data.success === true) {
                    toast.success(result.data.message, {
                      position: "top-right",
                      autoClose: 5000,
                      hideProgressBar: false,
                      closeOnClick: true,
                      pauseOnHover: true,
                      draggable: true,
                      progress: undefined,
                      theme: "light",
                    })
                    // alert(response.data.message);
                    setTimeout(() => {
                      navigate("/");
                    }, 1000);
                    console.log("login success");
                  } 
                }
               catch (error){
                console.log("Error at update password: ", error)
                toast.error(error.response.data.message);
               
               }
    }
    return (
        <div>
            <h3>Reset Password <span style={{ color: "red" }}>Link</span></h3> <br />
            <form onSubmit={updatePassword}>
                <div class="form-group">
                    <label for="exampleInputEmail1">Email address</label>

                    <input type="email" class="form-control" id="exampleInputEmail1"
                        aria-describedby="emailHelp" placeholder="Enter email" value={email}
                        onChange={(e) => { setEmail(e.target.value) }} />

                </div>

                <div class="form-group">
                    <label for="exampleInputPassword1">Password</label>

                    <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password"
                        value={password} onChange={(e) => { setPassword(e.target.value) }} />

                </div> 
                <br />

                <button type="submit" class="btn btn-primary">Changed</button>
            </form>
        </div>
    )
}

export default ResetPassword
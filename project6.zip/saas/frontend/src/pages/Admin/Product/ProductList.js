import React from 'react'
import AdminNavbar from "../Navbar/Navbar"
import  { useEffect, useState } from 'react'
import { Col, Button, Row, Form, Card, Container } from "react-bootstrap"
import axios from 'axios'
import Table from 'react-bootstrap/Table';
import { ToastContainer, toast } from 'react-toastify';


function ProductList() {
    const [productList, setProductList] = useState([]);
    const fetchAllProduct = async() => {
        try {
            const data = await axios.get(`http://localhost:5003/get-productlist`);
            console.log("data at product: ", data);
            setProductList(data.data.product);
        } catch (error) {
            console.log("Error at ProductList: ", error);
        }
        
    }

    const handleRemove = async (id) => {
        try {
            console.log("id: ", id)
            const { data } = await axios.patch(`http://localhost:5003/remove-product?productId=${id}`);
            if (data.success === true) {
                toast.success(data.message);
                fetchAllProduct();
            }
            console.log("data of remove: ", data);
        } catch (error) {
            console.log("Error at handleProduct: ", error);
        }
    }
    
    useEffect(() => {
      fetchAllProduct();
    },[])
    console.log("productList: ", productList.isActive);
    return (
        <>
            {/* <AdminNavbar /> */}
            <h1>ProductList</h1>
            <Table class="table" style={{width:"98%", margin:"1%",padding:"2%", border:"ridge"}} >
                <thead>
                    <tr>
                        <th scope="col">Index</th>
                        <th scope="col">Product</th>
                        <th scope='col'>Customer_Name</th>
                        <th scope='col'>Price</th>
                        <th scope='col'>Stock</th>
                        <th scope='col'>Status</th>
                    </tr>
                </thead>
                <tbody >
                    {productList?.length > 0 && productList.map((product, index) => (

                        <tr>
                            <th scope="row">{product.id}</th>
                            <td>{product.product_name}</td>
                            <td>{product.Nilesh_saas_customer.customer_name}</td>
                            <td>{product.price}</td>
                            <td>{product.stock}</td>
                            <td>
                            <td>
                                {product.isActive ? (
                                    <Form.Check // prettier-ignore
                                        type="switch"
                                        id="custom-switch"
                                        checked
                                        onClick={() => { handleRemove(product.id) }}
                                    />
                                ) : <Form.Check // prettier-ignore
                                    type="switch"
                                    id="custom-switch"
                                    onClick={() => { handleRemove(product.id) }}
                                />}
                            </td>
                            </td>
                            <ToastContainer />
                        </tr>
                    ))
                    }
                </tbody>
            </Table>
        </>
    )
}

export default ProductList
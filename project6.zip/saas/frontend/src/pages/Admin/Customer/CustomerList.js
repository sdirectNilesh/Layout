import React from 'react'
import AdminNavbar from "../Navbar/Navbar"
import { useEffect, useState } from 'react'
import { Col, Button, Row, Form, Card, Container } from "react-bootstrap"
import axios from 'axios'
import Table from 'react-bootstrap/Table';
import { ToastContainer, toast } from 'react-toastify';

function CustomerList() {
    const [customerList, setCustomerList] = useState([]);
    const fetchAllCustomer = async () => {
        try {
            const data = await axios.get(`http://localhost:5003/get-customerlist`);
            console.log("data at customer: ", data);
            setCustomerList(data.data.customer);
        } catch (error) {
            console.log("Error at CustomerList: ", error);
        }

    }

useEffect(() => {
    handleRemove();
})

    const handleRemove = async (id) => {
        try {
            console.log("id: ", id)
            const { data } = await axios.patch(`http://localhost:5003/remove-customer?customerId=${id}`);
            if (data.success === true) {
                toast.success(data.message);
            }
            console.log("data of remove: ", data);
        } catch (error) {
            console.log("Error at error: ", error);
        }
    }

    useEffect(() => {
        fetchAllCustomer();
    }, [])
    console.log("customerList: ", customerList.isActive);
    return (
        <>
            {/* <AdminNavbar /> */}
            <h1>CustomerList</h1>
            <Table class="table" style={{ width: "98%", margin: "1%", padding: "2%", border: "ridge" }}>
                <thead>
                    <tr>
                        <th scope="col">Index</th>
                        <th scope="col">Customer</th>
                        <th scope='col'>Organization_Name</th>
                        <th scope='col'>Phone</th>
                        <th scope='col'>Status</th>
                    </tr>
                </thead>
                <tbody >
                    {customerList?.length > 0 && customerList.map((customer, index) => (

                        <tr>
                            <th scope="row">{index+1}</th>
                            <td>{customer.customer_name}</td>
                            <td>{customer.Nilesh_saas_organization.organization_name}</td>
                            <td>{customer.phone}</td>
                            <td>
                                {customer.isActive ? (
                                    <Form.Check // prettier-ignore
                                        type="switch"
                                        id="custom-switch"
                                        checked
                                        onClick={() => { handleRemove(customer.id) }}
                                    />
                                ) : <Form.Check // prettier-ignore
                                    type="switch"
                                    id="custom-switch"
                                    onClick={() => { handleRemove(customer.id) }}
                                />}
                            </td>
                            <ToastContainer />
                        </tr>
                    ))
                    }
                </tbody>
            </Table>
        </>
    )
}

export default CustomerList
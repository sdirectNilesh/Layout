import axios from 'axios';
import { Button, Dropdown, Nav } from 'react-bootstrap';
import Container from 'react-bootstrap/Container';
import Navbar from 'react-bootstrap/Navbar';
import { Link, useNavigate } from 'react-router-dom';
import jwt_decode from 'jwt-decode'
import { useEffect } from 'react';

function AdminNavbar() {

    const navigate = useNavigate();
    // Function to check token expiration
    const checkTokenExpiration = () => {
        const token = localStorage.getItem('token');
        if (token) {
            const decodedToken = jwt_decode(token);
            if (decodedToken.exp < Date.now() / 1000) {
                // Token is expired, log the user out
                console.log("ghgg", decodedToken.exp);
                userLogout();
            }
        }
    };

    // Set up a timer to periodically check token expiration
    const tokenCheckInterval = setInterval(checkTokenExpiration, 5000); // Check every second

    
    const userLogout = () => {
        // When user logs out
        clearInterval(tokenCheckInterval); // Clear the timer
        const token = localStorage.clear();
        console.log("tok: ", token);
        if (!token) {
            navigate("/");
        }
    };



    return (
        <Navbar className="bg-body-tertiary">
            <Container>
                <Dropdown>
                    <Dropdown.Toggle variant="success" id="dropdown-basic" style={{ marginRight: "15px", marginLeft: "-45px" }}>
                        Home
                    </Dropdown.Toggle>
                    <Dropdown.Menu style={{ marginRight: "10px", marginLeft: "-47px", marginTop: "5px" }}>
                        <Dropdown.Item href="/admin">Home</Dropdown.Item>
                        <Dropdown.Item href="/admin/adminorganization">Organization</Dropdown.Item>
                        <Dropdown.Item href="/admin/admincustomer">Customer</Dropdown.Item>
                        <Dropdown.Item href="/admin/adminproduct">Product</Dropdown.Item>
                    </Dropdown.Menu>
                </Dropdown>
                <Navbar.Brand href="#home">Admin DashBoard</Navbar.Brand>
                <Navbar.Toggle />
                <Navbar.Collapse className="justify-content-end">
                    <Button variant="primary" style={{ marginLeft: "15px", marginRight: "-45px" }} onClick={userLogout}>LogOut</Button>
                </Navbar.Collapse>
            </Container>
        </Navbar>
    );
}

export default AdminNavbar;
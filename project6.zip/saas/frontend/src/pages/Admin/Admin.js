import React, { useEffect, useState } from 'react'
import AdminNavbar from "./Navbar/Navbar"
import jwt_decode from "jwt-decode";
import OrganizationList from './Organization/OrganizationList';
import axios from 'axios';
import AddSubscription from './Subscription/AddSubscription';
import { Col, Button, Row, Form, Card, Container, Table } from "react-bootstrap"
import { ToastContainer, toast } from 'react-toastify';

function Admin() {
    const decode = jwt_decode(localStorage.getItem('token'));
    console.log("admin dec: ", decode)
    const [subscriptionList, setSubcriptionList] = useState([]);

    const fetchAllSubscription = async () => {
        try {
            const data = await axios.get(`http://localhost:5003/get-subscription`);
            console.log(data.data.getSubscription)
            setSubcriptionList(data.data.getSubscription);
        } catch (error) {
            console.log("Error at fetchAllSuscription: ", error);
        }
    }

    console.log("subscription: ", subscriptionList);

    const handleRemove = async (id) => {
        try {
            console.log("id: ", id)
            const { data } = await axios.patch(`http://localhost:5003/remove-subscription?subscriptionId=${id}`);
            if (data.success === true) {
                toast.success(data.message);
                fetchAllSubscription()
            }
            console.log("data of remove: ", data);
        } catch (error) {
            console.log("Error at error: ", error);
        }
    }



    useEffect(() => {
        fetchAllSubscription();
    }, [])


    return (
        <>
            <div className='AdminNav'>
                {/* <AdminNavbar /> */}
                <AddSubscription />
            </div>
            <div>
                <Table class="table" >
                    <thead>
                        <tr>
                            <th scope="col">Index</th>
                            <th scope="col">Subscription</th>
                            <th scope='col'>Price</th>
                            <th scope='col'>Member Limit</th>
                        </tr>
                    </thead>
                    <tbody >
                        {subscriptionList?.length > 0 && subscriptionList.map((subscription,index) => (

                            <tr>
                                <th scope="row">{index+1}</th>
                                <td>{subscription.subcriptionName}</td>
                                <td>{subscription.subcriptionPrice}</td>
                                <td>{subscription.memberCount}</td>
                                {subscription.isActive ? (
                                    <Form.Check // prettier-ignore
                                        type="switch"
                                        id="custom-switch"
                                        checked
                                        onClick={(e) => { handleRemove(subscription.id) }}
                                    />
                                ) : <Form.Check // prettier-ignore
                                    type="switch"
                                    id="custom-switch"
                                    onClick={(e) => { handleRemove(subscription.id) }}
                                />}

                                <ToastContainer />
                            </tr>
                        ))
                        }
                    </tbody>
                </Table>
            </div>
        </>
    )
}

export default Admin;
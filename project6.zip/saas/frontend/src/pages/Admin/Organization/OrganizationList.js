import React from 'react'
import AdminNavbar from "../Navbar/Navbar"
import { useEffect, useState } from 'react'
import { Col, Button, Row, Form, Card, Container } from "react-bootstrap"
import axios from 'axios'
import Table from 'react-bootstrap/Table';
import { ToastContainer, toast } from 'react-toastify';


function OrganizationList() {
    const [organizationList, setOrganizationList] = useState([]);
    const fetchAllOrganization = async () => {
        try {
            const data = await axios.get(`http://localhost:5003/get-organizationlist`);

            console.log("data: ", data);
            setOrganizationList(data.data.organization);
        } catch (error) {
            console.log("Error at OrganizationList: ", error);
        }

    }

    const handleRemove = async (id) => {
        try {
            console.log("id: ", id)
            const { data } = await axios.patch(`http://localhost:5003/remove-organization?organizationId=${id}`);
            if (data.success === true) {
                toast.success(data.message);
            }
            console.log("data of remove: ", data);
        } catch (error) {
            console.log("Error at error: ", error);
        }
    }

    useEffect(() => {
        fetchAllOrganization();
    }, [])
    console.log("organizationList: ", organizationList.isActive);
    return (
        <>
            {/* <AdminNavbar /> */}
            <h1>Organization</h1>
            <Table class="table" style={{ width: "98%", margin: "1%", padding: "2%", border: "ridge" }}>
                <thead>
                    <tr>
                        <th scope="col">Index</th>
                        <th scope="col">Organization</th>
                        <th scope='col'>Subscription</th>
                        <th scope='col'>Status</th>
                    </tr>
                </thead>
                <tbody >
                    {organizationList?.length > 0 && organizationList.map((organization, index) => (

                        <tr>
                            <th scope="row">{organization.id}</th>
                            <td>{organization.organization_name}</td>
                            <td>{organization.Nilesh_saas_subscription.subcriptionName}</td>
                            <td>
                                {organization.isActive ? (
                                    <Form.Check // prettier-ignore
                                        type="switch"
                                        id="custom-switch"
                                        checked
                                        onClick={() => { handleRemove(organization.id) }}
                                    />
                                ) : <Form.Check // prettier-ignore
                                    type="switch"
                                    id="custom-switch"
                                    onClick={() => { handleRemove(organization.id) }}
                                />}
                            </td>
                            <ToastContainer />
                        </tr>
                    ))
                    }
                </tbody>
            </Table>
        </>
    )
}

export default OrganizationList
import React, { useEffect, useState } from 'react'
import { Col, Button, Row, Form, Card, Container } from "react-bootstrap"
import jwt_decode from "jwt-decode";
import axios from 'axios';
import { Link, useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';




function AddSubscription() {

    const navigate = useNavigate();
    const token = localStorage.getItem('token');
    console.log(token);
    const [subcriptionName, setSubcriptionName] = useState('');
    const [subcriptionPrice, setSubcriptionPrice] = useState('');
    const [memberCount, setMemberCount] = useState('');

    const backtoHome = () => {
        navigate('/product/home')
    }

    const addSubscription = async (e) => {
        e.preventDefault();
        const res = axios
            .post(`http://localhost:5003/add-subscription`,
                {
                    subcriptionName,
                    subcriptionPrice,
                    memberCount
                },
                {
                    headers: {
                        Authorization: localStorage.getItem('token'),
                        'Accept': 'application/json',
                        'Content-Type': 'application/json'

                    }
                }
            ).then((response) => {
                if (response.data.success === false) {
                    toast.error("Please log in again");
                    navigate('/admin');
                }
                else{
                    console.log(response);
                    toast.success("Added successfully")
                }
            }).catch(() => {
                console.log("err");
            });
    }
    useEffect(() => {
        navigate("/admin");
    }, [])  

    return (
        <div>
            <Container>
                <Row className="vh-100 d-flex justify-content-center align-items-center">
                    <Col md={8} lg={6} xs={12}>
                        <div className="border border-3 border-primary"></div>
                        <Card className="shadow">
                            <Card.Body>
                                <div className="mb-3 mt-md-4">
                                    <h2 className="fw-bold mb-2 text-uppercase ">Add Subscription</h2>
                                    <div className="mb-3">
                                        <Form method='POST' onSubmit={addSubscription} >
                                            <Form.Group className="mb-3" controlId="formBasicEmail">
                                                <Form.Label className="text-center" aria-required>
                                                    Subcription Name
                                                </Form.Label>
                                                <Form.Control type="text" placeholder="Subscription Name" value={subcriptionName} onChange={(e) => setSubcriptionName(e.target.value)} required />
                                            </Form.Group>

                                            <Form.Group
                                                className="mb-3"
                                                controlId="formBasicPassword"
                                            >
                                                <Form.Label aria-required>Subcription Price</Form.Label>
                                                <Form.Control type="number" placeholder="Subscription Price" value={subcriptionPrice} onChange={(e) => setSubcriptionPrice(e.target.value)} required />
                                            </Form.Group>
                                            <Form.Group
                                                className="mb-3"
                                                controlId="formBasicPassword"
                                            >
                                                <Form.Label aria-required>Member Limit</Form.Label>
                                                <Form.Control type="number" placeholder="Member Limit" value={memberCount} onChange={(e) => setMemberCount(e.target.value)} required />
                                            </Form.Group>
                                            <br></br>
                                            <div className="d-grid" mb-3>
                                                <Button variant="primary" type="submit" value="addSubscription" >
                                                    Add
                                                </Button>

                                            </div>
                                        </Form>
                                    </div>
                                </div>
                            </Card.Body>
                        </Card>
                    </Col>
                </Row>
            </Container>
        </div >
    )
}

export default AddSubscription
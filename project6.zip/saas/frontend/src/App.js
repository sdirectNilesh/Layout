import './App.css';
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import PublicRoutes from './routes/Public.route';
import Login from './pages/Login';
import Signup from './pages/Signup';
import Pagenotfound from './pages/Pagenotfound';
import Admin from './pages/Admin/Admin';
import OrganizationList from './pages/Admin/Organization/OrganizationList';
import CustomerList from './pages/Admin/Customer/CustomerList';
import ProductList from './pages/Admin/Product/ProductList';
import Organization from './pages/organization/Organization';
import Addcustomer from './pages/organization/Addcustomer';
import Customer from './pages/customer/Customer';
import Addproduct from './pages/customer/Addproduct';
import AdminRoutes from './routes/Admin.route';
import OrganizationRoutes from './routes/Organization.route';
import CustomerRoutes from './routes/Customer.route';
import ResetLink from './pages/ResetLink';
import ResetPassword from './pages/ResetPassword';
import OrganizationCustomersProduct from './pages/organization/CustomersProductList';
import 'react-toastify/dist/ReactToastify.css';
import CustomerInfo from './pages/customerProfile/customerProfile';
import EditName from './pages/customerProfile/editName';
import EditPassword from './pages/customerProfile/editPassword';


function App() {
  return (
    <div className="App">

      <BrowserRouter>

        <Routes>
          <Route path="/" element={<PublicRoutes />} >
            <Route index element={<Login />} />
            <Route path="/signup" element={<Signup />} />
          </Route>

          <Route path='/organization' element={<OrganizationRoutes />} >
            <Route index element={<Organization />} />
            <Route path='/organization/addcustomer' element={<Addcustomer />} />
            <Route path='/organization/customers-products' element={<OrganizationCustomersProduct />} />
          </Route >
          <Route path='/customer' element={<CustomerRoutes />} >
            <Route index element={<Customer />} />
            <Route path='/customer/addproduct' element={<Addproduct />} />
            <Route path='/customer/customer-profile' element={<CustomerInfo />} />
            <Route path='/customer/edit-name' element={<EditName />} />
            <Route path='/customer/edit-password' element={<EditPassword />} />
          </Route >
          <Route path='/admin' element={<AdminRoutes />}>
            <Route index element={<Admin />} />
            <Route path='/admin/adminorganization' element={<OrganizationList />} />
            <Route path='/admin/admincustomer' element={<CustomerList />} />
            <Route path='/admin/adminproduct' element={<ProductList />} />
          </Route>

          <Route path="/reset-organization" element={<ResetLink />} />
          <Route path="/reset-password/:resetToken" element={<ResetPassword />} />

          <Route path="*" Component={Pagenotfound} />
        </Routes>

      </BrowserRouter>
    </div>
  );
}

export default App;

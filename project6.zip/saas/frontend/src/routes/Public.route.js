import React from 'react'
import { Navigate, Outlet } from 'react-router-dom'
import jwt_decode from "jwt-decode";


function PublicRoutes() {

  const token = localStorage.getItem('token');
  if (token) {
    const decode = jwt_decode(localStorage.getItem('token'));
    if(decode && decode.isAdmin){
      return <Navigate to="/admin" />
    }
   else if(decode && decode.isOrganization){
    return <Navigate to="/organization" />
   }
   else if(decode && decode.isCustomer){
    return <Navigate to="/customer" />
   }
  }
  return <Outlet />
}

/* Here Outlet means the child routes in public route in app component */

export default PublicRoutes
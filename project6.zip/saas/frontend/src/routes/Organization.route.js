import React from 'react'
import { Outlet, Navigate } from 'react-router-dom'
import jwt_decode from "jwt-decode";


function OrganizationRoutes() {
  
  const token = localStorage.getItem('token');
  console.log("decode: ", token);
  if (token) {
    const decode = jwt_decode(token);
    if(decode && decode.isOrganization){
        return <Outlet />
    }
  }
  return <Navigate to="/" />
}

/* Here Outlet means the child routes in protected route in app component */

export default OrganizationRoutes
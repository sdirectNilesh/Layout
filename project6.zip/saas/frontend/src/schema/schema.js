import * as Yup from "yup"; 

const sigupSchema = Yup.object({
    organization_name: Yup.string().required("please provide your organization_name"),
    email: Yup.string().email().required("please provide your email"),
    password: Yup.string().min(6).required("please provide password you want"),
    subscriptionId: Yup.string().required("please select a subscription you want")
})

const loginSchema = Yup.object({
    email: Yup.string().email().required("please provide your email"),
    password: Yup.string().min(6).required("please provide password you want"),
})

const editNameSchema = Yup.object({
    newName: Yup.string().required("please provide your name")
});

const customerPasswordSchema = Yup.object({
    currentPassword: Yup.string().min(6).required("please provide your password"), 
    newPassword: Yup.string().min(6).required('please enter your new password'), 
    confirmPassword: Yup.string().min(6).required("please confirm password"), 
});

export {sigupSchema, loginSchema, editNameSchema, customerPasswordSchema}
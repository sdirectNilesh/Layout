const db = require("../config/db");
const {DataTypes} = require('sequelize');
const Subscription = require("./subscription");

const Organizations = db.define("Nilesh_saas_organization", {
    id:{
        type:DataTypes.INTEGER,
        primaryKey : true,
        allowNull: false,
        autoIncrement : true
    },
    organization_name: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true
    },
    email:{
        type:DataTypes.STRING,
        allowNull:false,
        unique:true
    },
    password:{
        type:DataTypes.STRING,
        allowNull:false,
    },
    isActive:{
        type:DataTypes.BOOLEAN,
        defaultValue:true
    },
    subscriptionId:{
        type:DataTypes.INTEGER,
        allowNull:false
    },
  
},
{
    tableName:"Nilesh_saas_organization",
    createdAt:"createdAt",
    updatedAt:"updatedAt",
    deletedAt:"deletedAt",
    paranoid:true,
    timestamp:true
}
);

Subscription.hasMany(Organizations,{
    foreignKey:'subscriptionId'
});
Organizations.belongsTo(Subscription,{
    foreignKey:'subscriptionId'
})
module.exports = Organizations;
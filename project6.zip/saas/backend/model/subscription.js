const DataTypes = require('sequelize');
const db = require('../config/db');

const Subscription = db.define("Nilesh_saas_subscription",{
    id:{
        type:DataTypes.INTEGER,
        primaryKey : true,
        autoIncrement:true,
        allowNull:false
    },
    subcriptionName:{
        type:DataTypes.STRING,
        unique:true,
        allowNull:false
    },
    subcriptionPrice:{
        type:DataTypes.INTEGER,
        allowNull:false
    },
    memberCount:{
        type:DataTypes.INTEGER,
        allowNull:false
    },
    isActive:{
        type:DataTypes.BOOLEAN,
        defaultValue:true
    },

});

module.exports = Subscription;
const Admin = require('./admin');
const Organizations = require('./organization');
const Subscription = require('./subscription');
const Customer = require('./customer');
const Product = require('./product');
const Vendor = require('./vendor');

const tableSync = async () => {
    try {
        await Admin.sync({force:false});
        await Organizations.sync({ force: false });
        await Subscription.sync({force:false});  
        await Customer.sync({force:false});  
        await Product.sync({force:false});
        // await Vendor.sync({force:false});
    } catch (error) {
        console.log("Error at tableSync: ", error);
    }
};
module.exports = tableSync;
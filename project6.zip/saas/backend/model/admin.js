const DataTypes = require('sequelize');
const db = require("../config/db");

const Admin = db.define('Nilesh_saas_Admin', {
    email:{
        type:DataTypes.STRING
    },
    password:{
        type:DataTypes.STRING
    }
});
module.exports = Admin;
const DataTypes = require('sequelize');
const db = require('../config/db');
const Organizations = require('./organization');

const Customer = db.define('Nilesh_saas_customer', {
    id:{
        type:DataTypes.INTEGER,
        allowNull:false,
        autoIncrement: true,
        primaryKey:true
    },
    customer_name:{
        type:DataTypes.STRING,
        allowNull:false
    },
    email:{
        type:DataTypes.STRING,
        allowNull:false,
        unique:true,
        validate:{
            isEmail:true
        }
    },
    password:{
        type:DataTypes.STRING,
        allowNull:false
    },
    phone:{
        type:DataTypes.STRING,
        allowNull:false,
        validate:{
            min:10
        }
    },
    isActive:{
        type:DataTypes.BOOLEAN,
        defaultValue:true
    },
    organizationId:{
        type:DataTypes.INTEGER,
        allowNull:false,
        reference:{
            model:Organizations,
            key:'id'
        }
    },
    resetToken: { 
        type: DataTypes.STRING 
    },
    resetTokenExpiration : {
         type: DataTypes.STRING 
        },
},
{
 tableName:"Nilesh_saas_customer",
 createdAt:"createdAt",
 updatedAt:"updatedAt",
 deletedAt:"deletedAt",
 paranoid:true,
 timestamps:true
});

Organizations.hasMany(Customer,{
    foreignKey:"organizationId"
});
Customer.belongsTo(Organizations,{
    foreignKey:"organizationId"
});

module.exports = Customer;
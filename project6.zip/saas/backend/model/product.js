const DataTypes = require('sequelize');
const db = require('../config/db');
const Customer = require('./customer');

const Product = db.define('Nilesh_saas_product', {
    id:{
        type:DataTypes.INTEGER,
        allowNull:false,
        autoIncrement:true,
        primaryKey:true
    },
    product_name:{
        type:DataTypes.STRING,
        allowNull:false
    },
    brand:{
        type:DataTypes.STRING,
        allowNull:false,
    },
    price:{
        type:DataTypes.INTEGER,
        allowNull:false
    },
    stock:{
        type:DataTypes.INTEGER,
        allowNull:false
    },
    isActive:{
        type:DataTypes.BOOLEAN,
        defaultValue:true
    },
    customerId:{
        type:DataTypes.INTEGER,
        allowNull:false
    }
},
{
    tableName:"Nilesh_saas_product",
    createdAt:"createdAt",
    updatedAt:"updatedAt",
    deletedAt:"deletedAt",
    paranoid:true,
    timestamps:true
}
);

Customer.hasMany(Product, {
    foreignKey:'customerId'
});
Product.belongsTo(Customer, {
    foreignKey:'customerId'
});

module.exports = Product
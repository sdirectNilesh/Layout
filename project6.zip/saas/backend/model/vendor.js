const DataTypes = require('sequelize');
const db = require('../config/db');

const Vendor = db.define('Nilesh_saas_customer', {
    id:{
        type:DataTypes.INTEGER,
        allowNull:false,
        autoIncrement: true,
        primaryKey:true
    },
    name:{
        type:DataTypes.STRING,
        allowNull:false
    },
    email:{
        type:DataTypes.STRING,
        allowNull:false,
        unique:true,
        validate:{
            isEmail:true
        }
    },
    password:{
        type:DataTypes.STRING,
        allowNull:false
    },
    isActive:{
        type:DataTypes.BOOLEAN,
        defaultValue:true
    },
},
{
 tableName:"Nilesh_saas_vendor",
 createdAt:"createdAt",
 updatedAt:"updatedAt",
 deletedAt:"deletedAt",
 paranoid:true,
 timestamps:true
});


module.exports = Vendor;
require("dotenv").config();
const Organizations = require('../../model/organization');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { Op } = require("sequelize");

exports.addOrganization = async (req, res) => {
    try {
        const { organization_name, email, password, subscriptionId } = req.body;
        console.log("subs: ", subscriptionId);
        if (!subscriptionId) {
            return res.status(203).json({ success: false, message: "please select a sbcription first" });
        }
        else {
            const organizationExist = await Organizations.findOne({
                where: {
                    [Op.or]:
                        [{ organization_name: organization_name }, { email: email }]
                },
                paranoid: false
            });
            if (organizationExist) {
                if (organizationExist.deletedAt != null) {
                    const restoreOrganization = await organizationExist.restore();
                    res.status(201).json({ success: true, message: "Organization is active now", restoreOrganization: restoreOrganization });
                } return res.status(404).json({ success: false, message: "Orgainization already exist" })
            }
            else {
                const salt = await bcrypt.genSalt(10);
                const hashedPassword = await bcrypt.hash(password, salt);
                const addNewOrganization = await Organizations.create({ organization_name: organization_name, email: email, password: hashedPassword, subscriptionId:subscriptionId });
                return res.status(200).json({ success: true, message: "Your organization has been added", addNewOrganization: addNewOrganization })
            }
        }
    } catch (error) {
        console.log("Error at addOrganization: ", error);
    }
};

exports.signedInOrganization = async (req, res) => {
    try {
        const { email, password } = req.body;
        const organization = await Organizations.findOne({
            where: {
                [Op.and]: [{email:email}, {isActive: true}]
              }
        });
        if (organization) {
            const ispasswordMatched = await bcrypt.compare(password, organization.password);
            if (!ispasswordMatched) {
                return res.status(404).json({ success: false, message: "Invalid Credentials" });
            }
            else {
                const token = jwt.sign({ info: organization, isOrganization:true }, process.env.DB_SECRETKEY, { expiresIn: "1min" });
                return res.status(201).json({ success: true, message: "Logged In", token: token });
            }
        } return res.status(404).json({ success: false, message: "Invalid Credentials" });
    } catch (error) {
        console.log("Error at signedInOrganization: ", error);
    }
}

exports.removeOrganization = async(req ,res) => {
    try {
        const organizations = await Organizations.findOne({
            where:{
                id:req.query.organizationId
            }
        });
        console.log(organizations.isActive);
        if(organizations.isActive){
            organizations.isActive = false;
            await organizations.save();
            return res.status(200).json({success:true, message:"organizations is inactive now", isActive:false})
        }
        else {
            organizations.isActive = true;
            await organizations.save();
            return res.status(200).json({success:true, message:"organizations is active now", isActive:true})
        }
    } catch (error) {
       console.log("Error at remove subscription: ", error); 
    }
} 


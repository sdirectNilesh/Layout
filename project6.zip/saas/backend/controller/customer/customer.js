require("dotenv").config();
const Customer = require('../../model/customer');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const Op = require('sequelize');
const nodemailer = require("nodemailer");
const crypto = require('crypto');
const Subscription = require("../../model/subscription");
const Organizations = require("../../model/organization");

exports.addCustomer = async (req, res) => {
    try {
        const { customer_name, email, password, phone, organizationId } = req.body;
        if (organizationId) {
            const customerCount = await Customer.findAndCountAll({
                where:{
                    organizationId:organizationId
                }
            })
           console.log("customer==",customerCount)
            const org=await Organizations.findOne({where:{id:organizationId}})
            const subId=org.subscriptionId
            const subscription=await Subscription.findOne({where:{id:subId}})
            const memberCount=subscription.memberCount
           console.log("memberCount==",memberCount)

            if(customerCount.count>=memberCount)
            {
                return res.status(200).json({ success: true, message: "Customer Limit Reached For Your Subcription"})
            }
            const customerExist = await Customer.findOne({
                where: {
                    email: email
                },
                paranoid: false
            });
            if (customerExist) {
                if (customerExist.deletedAt != null) {
                    const restoreCustomer = await customerExist.restore();
                    return res.status(200).json({ success: true, message: "customer restored", customerExist: customerExist });
                }
                else {
                    return res.status(404).json({ success: false, error: "Customer with this Email already exist" });
                }
            }
            else {
                const salt = await bcrypt.genSalt(10);
                const hashedPassword = await bcrypt.hash(password, salt);
                const newCustomer = await Customer.create({ customer_name: customer_name, email: email, password: hashedPassword, phone: phone, organizationId: organizationId });
                return res.status(201).json({ success: true, message: "customer is added", newCustomer: newCustomer });
            }
        } return res.status(203).json({ success: false, message: "Unidentified organization" });
    } catch (error) {
        console.log("Error at addCustomer: ", error);
    }
};

exports.signedInCustomer = async (req, res) => {
    try {
        const { email, password } = req.body;
        const customerExist = await Customer.findOne({
            where: {
                email: email
            }
        });
        if (!customerExist) {
            return res.status(404).json({ success: false, message: "Invalid Credentials" });
        }
        if (customerExist.isActive) {
            const isPasswordMatched = await bcrypt.compare(password, customerExist.password);
            if (isPasswordMatched) {
                const token = jwt.sign({ info: customerExist, isCustomer: true }, process.env.DB_SECRETKEY, { expiresIn: "4h" });
                return res.status(201).json({ success: true, message: "you are logged in", token: token });
            } return res.status(404).json({ success: false, message: "Invalid credentials" });
        } return res.status(404).json({ success: false, message: "Invalid Credentials" });
    } catch (error) {
        console.log("Error at signedIncustomer: ", error);
    }
}

exports.getOrganizationCustomer = async (req, res) => {
    try {
        // const organizationId = req.query;
        // console.log(organizationId)
        const customer = await Customer.findAll({
            where: {
                organizationId: req.query.organizationId
            },
            paranoid: false
        });
        if (customer) {
            return res.status(200).json({ success: true, message: "customer list", customer: customer })
        } return res.status(404).json({ success: false, message: "No customer found" });
    } catch (error) {
        console.log("Error at getOrganizationCustomer: ", error);
    }
}

exports.forgetPassCustomer = async (req, res) => {
    try {
        const { email } = req.body;
        const user = await Customer.findOne({ where: { email: email } });
        if (!user) {
            return res.status(404).json({ success: false, message: "Invalid Credentials" });
        }
        else {
            if (!user.isActive) {
                return res.status(404).json({ success: false, message: 'User is inactive' });
            }
            else {
                const resetToken = crypto.randomBytes(20).toString('hex');
                const resetTokenExpiration = Date.now() + 2 * 60000;
                console.log("resetTokenExpiration", resetTokenExpiration)
                user.resetToken = resetToken;
                user.resetTokenExpiration = resetTokenExpiration;
                const link = `<p>Click <a target="_blank" href="http://localhost:3000/reset-password/${resetToken}">here</a> to reset your password.</p>`;
                await user.save();
                const transporter = nodemailer.createTransport({
                    service: "gmail",
                    port: 587,
                    auth: {
                        user: 'sdirectnilesh@gmail.com',
                        pass: 'hwyltlepjazxcwmh'
                    },
                });
                await transporter.sendMail({
                    to: email,
                    subject: 'Password Reset',
                    html: link
                });
                return res.status(200).json({success:true,  message: 'Password reset link send to your register email ID', resetToken: resetToken }); 
            }
        }
    } catch (error) {
        return res.status(500).json({ message: 'An error occurred' });
    }
}

exports.passwordUpdateCustomer = async (req, res) => {
    const { password, email } = req.body
    const { resetToken } = req.params
    try {
        const user = await Customer.findOne({ where: { email: email } });

        if (!user) {
            return res.status(200).json({success:true,  message: 'User not found' });
        }
        if (user.resetToken !== resetToken || user.resetTokenExpiration < Date.now()) {
            return res.status(200).json({success: true, message: 'Invalid or expired reset token' });
        }

        const saltRounds = 10;
        const hashedPassword = await bcrypt.hash(password, saltRounds);

        user.password = hashedPassword;

        await user.save();
        return res.status(200).json({success:true,  message: 'Password updated successfully', token: user.resetToken });
    } catch (error) {
        return res.status(500).json({success: false,  message: 'Internal server error' });
    }

}



exports.removeCustomer = async (req, res) => {
    try {
        const customer = await Customer.findOne({
            where: {
                id: req.query.customerId
            }
        });
        console.log(customer.isActive);
        if (customer.isActive) {
            customer.isActive = false;
            await customer.save();
            return res.status(200).json({ success: true, message: "customer is inactive now", isActive: false })
        }
        else {
            customer.isActive = true;
            await customer.save();
            return res.status(200).json({ success: true, message: "customer is active now", isActive: true })
        }
    } catch (error) {
        console.log("Error at remove subscription: ", error);
    }
} 

exports.updateName = async(req, res) => {
    try {
        const {newName} = req.body;
        const customerExist = await Customer.findOne({
            where:{
                id:req.query.customerId
            }
        });
        if(customerExist){
            customerExist.customer_name = newName;
            await customerExist.save();
            return res.status(201).json({success:true, message:"Name has been updated", customerExist:customerExist});
        } return res.status(500).json({success:false, message:"user not found"});
    } catch (error) {
        console.log("Error at updateName: ", error);
    }
}

exports.updatePassword = async (req, res) => {
    try {
        const {currentPassword, newPassword, confirmPassword} = req.body;
        const customer_id = req.query.customerId;
        console.log(req.body);
        const customer = await Customer.findOne({ where: { id:customer_id } });
        if (!customer) {
            return res.status(400).json({ error: 'Invalid customer' });
        }
        else {
            console.log("currpass: ", req.body.currentPassword)
            const isPasswordVerified = bcrypt.compareSync(currentPassword, customer.password);
            if (isPasswordVerified) {  
                if(newPassword === confirmPassword){
                    const salt = await bcrypt.genSalt(10);
                    const hashPwd = await bcrypt.hash(newPassword, salt);
                    customer.password = hashPwd;
                    await customer.save();
                    return res.status(201).json({ success: true, message: "Password Changed successfully!l" , customer:customer});
                }
            } return res.status(400).json({ error: 'Invalid Customer' });
        }
    } catch (error) {
        console.log("error: ", error);
    }
}

const DataTypes = require('sequelize');
const Subscription = require('../../model/subscription');


exports.addSubscription = async(req, res) => {
    try {
        const {subcriptionName, subcriptionPrice, memberCount} = req.body;
        const subscriptionExist = await Subscription.findOne({
            where:{
                subcriptionName:subcriptionName
            }
        });
        if(!subscriptionExist){
            const createSubscription = await Subscription.create({subcriptionName:subcriptionName, subcriptionPrice:subcriptionPrice, memberCount:memberCount});
            return res.status(201).json({success:true, message:"New subscription is added", createSubscription:createSubscription});
        } return res.status(404).json({success:false, message:"subscription is already added"});
    } catch (error) {
        console.log("Error at addSubscription: ", error);
    }
};

exports.getAllSubscription = async(req, res) => {
    try {
        const getSubscription = await Subscription.findAll();
        if(getSubscription){
            return res.status(201).json({success:true, getSubscription:getSubscription});
        } return res.status(404).json({success:false, message:"No subscription is available"})
    } catch (error) {
        console.log("Error at getSubscription: ", error);
    }
};

exports.getActiveSubscription = async(req, res) => {
    try {
        const getActiveSubscription = await Subscription.findAll({
            where:{
                isActive:true
            }
        });
        if(getActiveSubscription){
            return res.status(201).json({success:true, getActiveSubscription:getActiveSubscription});
        } return res.status(404).json({success:false, message:"No subscription is available"})
    } catch (error) {
        console.log("Error at getSubscription: ", error);
    }
};

exports.removeSubscription = async(req ,res) => {
    try {
        const subscription = await Subscription.findOne({
            where:{
                id:req.query.subscriptionId
            }
        });
        console.log(subscription.isActive);
        if(subscription.isActive){
            subscription.isActive = false;
            await subscription.save();
            return res.status(200).json({success:true, message:"Subscription is inactive now", isActive:false})
        }
        else {
            subscription.isActive = true;
            await subscription.save();
            return res.status(200).json({success:true, message:"Subscription is active now", isActive:true})
        }
    } catch (error) {
       console.log("Error at remove subscription: ", error); 
    }
} 
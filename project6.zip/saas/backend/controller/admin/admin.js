require("dotenv").config();
const Admin = require('../../model/admin');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const Organizations = require("../../model/organization");
const Subscription = require("../../model/subscription");
const Product = require("../../model/product");
const Customer = require("../../model/customer");

exports.addAdmin = async(req, res) => {
    try {
        const salt = await bcrypt.genSalt(10);
        const password = await bcrypt.hash("123456",salt);
        const createAdmin = await Admin.create({
            email:"admin@gmail.com",
            password:password
        });
        return res.status(201).json({success:true, message:"admin is added", createAdmin:createAdmin});
    } catch (error) {
        console.log("Error at addAdmin: ", error);
    }
};
exports.signedInAdmin = async(req, res) => {
    try {
        const {email, password} = req.body;
        console.log(req.body)
        const admin = await Admin.findOne({
            where:{
                email:email
            }
        });
        if(admin){
            const ispasswordMatched = await bcrypt.compare(req.body.password, admin.password);
            if(ispasswordMatched){
                const token =  jwt.sign({info:email, isAdmin:true}, process.env.DB_SECRETKEY, {expiresIn:"1h"});
                return res.status(200).json({success:true, message:"Logged In", token:token});
            } return res.status(404).json({success:false, message:"Please provide valid credentials"});
        } return res.status(404).json({success:false, message:"Please provide valid credentials"});
    } catch (error) {
        console.log("Error at signedInAdmin: ",error);
    }
};

exports.getOrganization = async(req, res) => {
    try {
        const organization = await Organizations.findAll({
            include:[
                {
                    model: Subscription
                }
            ]
        });
        if(organization){
            return res.status(200).json({success:true, message:"List of organization", organization:organization});
        } return res.status(404).json({success:false, message:"No Organization found"})
        
    } catch (error) {
        console.log("Error at getOrganization: ", error);
    }
}

exports.getCustomer = async(req, res) => {
    try {
        const customer = await Customer.findAll({
            include:[
                {
                    model:Organizations
                }
            ]
        });
        if(customer){
            return res.status(200).json({success:true, message:"Customer List", customer:customer});
        } return res.status(404).json({success:false, message:"No customer available"});
    } catch (error) {
        console.log("Error at getCustomer: ", error);
    }
};

exports.getProductList = async(req, res) => {
    try {
        const product = await Product.findAll({
            include:[
                {
                    model:Customer
                }
            ]
        });
        if(product){
            return res.status(200).json({success:true, message:"Product list", product:product});
        } return res.status(404).json({success:false, message:"No product is available"})
    } catch (error) {
        console.log("Error at getProduct: ", error);
    }
}
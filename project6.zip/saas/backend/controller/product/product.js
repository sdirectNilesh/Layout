const Product = require('../../model/product');
const { Op } = require('sequelize');
const { where } = require('sequelize');
const Customer = require('../../model/customer');

exports.addProduct = async (req, res) => {
    try {
        const { product_name, brand, price, stock } = req.body;
        const customerId = req.query.customerId;
        console.log(customerId)
        console.log(req.body)
        const productExist = await Product.findOne({
            where: {
                [Op.and]:
                    [{ product_name: product_name }, { customerId: req.query.customerId }]
            },
            paranoid: false
        });
        if (productExist) {
            if (productExist.deletedAt != null) {
                const restoreProduct = await productExist.restore();
                return res.status(200).json({ success: true, messsage: "Product is restored", restoreProduct: restoreProduct });
            } return res.status(404).json({ success: false, messsage: "product already exists" });
        }
        else {
            const newProduct = await Product.create({ product_name, brand, price, stock, customerId });
            return res.status(201).json({ success: true, messsage: "product has been added", newProduct: newProduct });
        }
    } catch (error) {
        console.log("Error at addProduct: ", error);
    }
};

exports.getProduct = async (req, res) => {
    try {
        // const { customerId } = req.query.id;
        const product = await Product.findAll({
            where: {
                customerId: req.query.customerId
            }
        });
        if (product) {
            return res.status(200).json({ success: true, messsage: "Here is your product", product: product });
        } return res.status(404).json({ success: true, messsage: "No product is available" });
    } catch (error) {
        console.log("Error at getProducts: ", error);
    }
}

exports.getAllCustomersProduct = async (req, res) => {
    try {
        // const { customerId } = req.query.id;
        const customer = await Customer.findAll({
            where:
            {
                organizationId: req.query.organizationId 
            },
                include: [
                    {
                        model: Product
                    }
                ]
        });
        if (customer) {
            return res.status(200).json({ success: true, messsage: "Here is your product", customer: customer });
        } return res.status(404).json({ success: true, messsage: "No product is available" });
    } catch (error) {
        console.log("Error at getAllProducts: ", error);
    }
}

exports.removeProduct = async(req ,res) => {
    try {
        const product = await Product.findOne({
            where:{
                id:req.query.productId
            }
        });
        console.log(product.isActive);
        if(product.isActive){
            product.isActive = false;
            await product.save();
            return res.status(200).json({success:true, message:"product is inactive now", isActive:false})
        }
        else {
            product.isActive = true;
            await product.save();
            return res.status(200).json({success:true, message:"product is active now", isActive:true})
        }
    } catch (error) {
       console.log("Error at remove product: ", error); 
    }
} 

exports.deleteProduct = async(req, res) => {
    try {
        const productExist = await Product.findOne({
            where:{
                id:req.query.productId
            }
        });
        if(productExist){
            const deletedProduct=await  Product.destroy ({
                where:{
                    id:req.query.productId
                }
            })
            return res.status(200).json({success: true, message:"product is deleted", deletedProduct:deletedProduct})
        } return res.status(404).json({ success: true, messsage: "No product is available" });
    } catch (error) {
        console.log("Error at deleteProduct: ", error);
    }
}
const express = require('express');
const { addCustomer, signedInCustomer, getOrganizationCustomer,forgetPassCustomer, passwordUpdateCustomer,removeCustomer, updateName, updatePassword } = require('../../controller/customer/customer');
const Authentiacate = require('../../middleware/auth');
const loginLimit = require('../../middleware/loginlimit');
const router = express.Router();

router.post('/add-customer', Authentiacate, addCustomer);
router.post('/signin-customer',loginLimit, signedInCustomer);
router.get('/get-organizationcustomer', getOrganizationCustomer);
router.patch('/remove-customer', removeCustomer);


router.post("/forgetPassCustomer", forgetPassCustomer)
router.post("/passwordUpdateCustomer/:resetToken", passwordUpdateCustomer)
router.post('/update-name', updateName);
router.post('/update-password', updatePassword);

module.exports = router;
const express = require('express');
const { addAdmin, signedInAdmin, getOrganization, getCustomer, getProductList } = require('../../controller/admin/admin');
const router = express.Router();
const loginLimit = require('../../middleware/loginlimit');

router.post('/add-admin',addAdmin);
router.post('/signin-admin',loginLimit, signedInAdmin);
router.get('/get-organizationlist', getOrganization);
router.get('/get-customerlist', getCustomer);
router.get('/get-productlist', getProductList);

module.exports = router;
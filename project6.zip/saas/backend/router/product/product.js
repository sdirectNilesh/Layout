const express = require('express');
const { addProduct, getProduct, getAllCustomersProduct, removeProduct, deleteProduct } = require('../../controller/product/product');
const Authentiacate = require('../../middleware/auth');
const router = express.Router();

router.post('/add-product', Authentiacate, addProduct);
router.patch('/remove-product', removeProduct);
router.delete('/delete-product', deleteProduct);
router.get('/get-product', getProduct);
router.get('/get-customers-product', getAllCustomersProduct);
module.exports = router;
const express = require('express');
const { addSubscription, removeSubscription, getActiveSubscription, getAllSubscription } = require('../../controller/subscription/subscription');
const Authentiacate = require('../../middleware/auth');
const router = express.Router();

router.post('/add-subscription', Authentiacate, addSubscription);
router.get('/get-subscription', getAllSubscription);
router.get('/get-active-subscription', getActiveSubscription);
router.patch('/remove-subscription', removeSubscription);

module.exports = router;
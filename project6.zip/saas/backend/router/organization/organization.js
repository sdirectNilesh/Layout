const express = require('express');
const { addOrganization, signedInOrganization, removeOrganization} = require('../../controller/organization/organization');
const loginLimit = require('../../middleware/loginlimit');
const router = express.Router();

router.post('/add-organization',addOrganization);
router.post('/signin-organization',loginLimit, signedInOrganization);
router.patch('/remove-organization', removeOrganization);


module.exports = router;
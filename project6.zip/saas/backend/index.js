const app = require('express')();
require('dotenv').config();
const port = process.env.PORT;
const bodyparser = require('body-parser');
const cors = require('cors');
const tableSync = require('./model/tablesync')();
app.use(cors());
require('./config/db');

app.use(bodyparser.urlencoded({ extended: true }));
app.use(bodyparser.json());

app.use('/', require('./router/organization/organization'));
app.use('/',require('./router/admin/admin'));
app.use('/',require('./router/customer/customer'));
app.use('/',require('./router/product/product'));
app.use('/', require('./router/subscription/subcription'));
app.use('/', require('./router/vendor/vendor'));

app.get('/', (req,res) => {
    console.log("hello from server")
});

app.listen(port, () => {
    console.log("server is listening on port: ",port);
})
require("dotenv").config();
const jwt = require('jsonwebtoken');

const Authentiacate = (req, res, next) => {
    try {
        const token = req.headers['authorization'];
        console.log({token});
        if(!token){
            return res.status(404).json({ success: false, message: "Token is not valid" })
        }
        if (token) {
            const decode = jwt.verify(token, process.env.DB_SECRETKEY);
            console.log("first", decode)
            if (decode) {
                req.info = decode.info;
                console.log("fdg", req.info)
                return next();
            }
            else {
                return res.status(401).json({ success: false, message: "Authentication failed" })
            }
        } 
    } catch (error) {
        console.log("Error at Authenticate: ", error);
    }
};

module.exports = Authentiacate;
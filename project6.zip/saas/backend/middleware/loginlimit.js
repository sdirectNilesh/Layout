const rateLimit = require('express-rate-limit');

const loginLimit = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 15,
    message: "Too many login attempts, please try again later",
}
);

module.exports = loginLimit;
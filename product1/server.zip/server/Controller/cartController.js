const NilproductCart_obj = require('../Models/cartModel');
const { Op } = require("sequelize");
const NilProduser_obj = require('../Models/userModel');
const Nilproduct_obj = require('../Models/prodModel');

exports.addtoCart = async (req, res) => {
    try {
        console.log(req.body);

        const cart = {
            productId: req.body.productId,
            userId: req.body.userId,
            count: req.body.count,
        };
        let user = await NilProduser_obj.findByPk(cart.userId);
        let product = await Nilproduct_obj.findByPk(cart.productId);
        

        let created_cart = await NilproductCart_obj.create(cart);
        res.status(201).json({ product: created_cart });
    } catch (error) {
        console.log(error)
    }
}

exports.getCart = async (req, res) => {
    try {
        console.log(req.body);
        const userId = req.params.id
        const data = await NilproductCart_obj.findAll({ 
            where: { userId: userId },
            include:[
                {model:Nilproduct_obj},
            ]
        });
        res.status(201).json({ product: data });
    } catch (error) {
        console.log(error)
    }
}


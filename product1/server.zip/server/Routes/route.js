const express = require('express');
const router = express.Router();
const { signup, signin } = require('../Controller/userController');
const { addProduct, getProduct, getSearch, deleteProduct, updateProduct, getallProduct } = require('../Controller/prodController');
const { userValidation } = require('../Middleware/user.validate');
const { forgotPassword, updatePassword } = require('../Controller/passwordController');
const { addtoCart, getCart} = require('../Controller/cartController')



router.post('/sign-up', userValidation, signup);
router.post('/sign-in', signin);
router.post('/forgot-password', forgotPassword);
router.post('/update-password', updatePassword);

router.get('/get-allproduct', getallProduct);

router.post('/add-product', addProduct);
router.get('/get-product', getProduct);
router.get('/search-product', getSearch);
router.delete('/delete-product/:id', deleteProduct);
router.post('/update-product', updateProduct);


router.post('/add-cart', addtoCart);
router.get('/get-cart/:id', getCart);

module.exports = router;

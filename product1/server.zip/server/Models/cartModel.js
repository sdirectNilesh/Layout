const { DataTypes} = require("sequelize");
const sequelize = require("../Database/db");
const Nilproduct_obj = require("./prodModel");
const NilProduser_obj = require("./userModel")

const NilproductCart_obj = sequelize.define('NilproductCart_obj', {
    // Model attributes are defined here
    productId: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    userId: {
        type: DataTypes.STRING,
        allowNull: false
    },
    count: {
        type: DataTypes.STRING,
        allowNull: false
    }
})

NilProduser_obj.hasMany(NilproductCart_obj, {
    foreignKey: "productId"
})
NilproductCart_obj.belongsTo(NilProduser_obj, {
    foreignKey: "productId"
})


Nilproduct_obj.hasMany(NilproductCart_obj, {
    foreignKey: "productId"
})
NilproductCart_obj.belongsTo(Nilproduct_obj, {
    foreignKey: "productId"
})


module.exports = NilproductCart_obj;
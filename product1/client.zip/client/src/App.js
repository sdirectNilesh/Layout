import './App.css';
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Home from './pages/Home';
import ProtectedRoutes from './routes/Protected.route';
import PublicRoutes from './routes/Public.route';
import Login from './pages/Login';
import Signup from './pages/Signup';
import Pagenotfound from './pages/Pagenotfound';
import Addproduct from './pages/Addproduct';
import ForgotPassword from './pages/Forgotpassword';
import UpdatePasword from './pages/Updatepassword';
import Product from './pages/Product';



function App() {
  return (
    <div className="App">
      <BrowserRouter>

        <Routes>
          <Route path="/" element={<PublicRoutes />} >
            <Route index element={<Login />} />                      
            <Route path="/signup" element={<Signup />} />
            <Route path="/forgotpassword" element={<ForgotPassword />} />
          </Route>

          <Route path="/product" element={<ProtectedRoutes />} >
            <Route index element={<Product />}/>
            <Route path='/product/home' element={<Home />}/>
            <Route path='/product/home/addproduct' element={<Addproduct />}/>
            <Route path='/product/home/updatepassword' element={<UpdatePasword />}/>
          </Route >
          <Route path="*"Component={Pagenotfound }/>
        </Routes>

      </BrowserRouter>
    </div>
  );
}

export default App;

import React from 'react'
import { useState } from 'react'
import {  useNavigate } from "react-router-dom";
import axios from 'axios';

const SignUp = () => {
    
    const [user, setUser] = useState({
        firstName: "",
        lastName: "",
        email: "",
        password: "",
        phone: ""
    })
    let name, value;
    const handleInput = (e) => {
        console.log(e);
        name = e.target.name;
        value = e.target.value;

        setUser({ ...user, [name]: value });
    }
    const navigate = useNavigate();
    const PostData = async(e) => {
       
        e.preventDefault();
        
        const {firstName, lastName, email, password, phone}= user;
       
        /* axios post request to save user data */
        const response = axios.post("http://localhost:3500/sign-up",{firstName, lastName, email, password, phone})
        .then((response) => {
        
         if (response.data.success === true) {
          alert(response.data.message);
           console.log("Registration succss");
           navigate("/");
         }
         else {
            alert(response.data.msg);
           console.log("Registration failed");
           navigate('/Signup');
         }
        })
        .catch((error) => {
         console.log(error)
        })
        console.log(response);
       }
   
  
    return (
        <div>
            <form method='POST'  onSubmit={PostData}>

                <div class="form-outline mb-4">
                    <input type="text" name="firstName" id="form1Example1" class="form-control" value={user.firstName} onChange={handleInput} autoComplete="off" required />
                    <label class="form-label" for="form1Example1">firstName</label>
                </div>

                <div class="form-outline mb-4">
                    <input type="text" name="lastName" id="form1Example1" class="form-control" value={user.lastName} onChange={handleInput} autoComplete="off" required />
                    <label class="form-label" for="form1Example1">lastName</label>
                </div>

                <div class="form-outline mb-4">
                    <input type="email" name="email" id="form1Example1" class="form-control" value={user.email} onChange={handleInput} autoComplete="off" required />
                    <label class="form-label" for="form1Example1">Email address</label>
                </div>


                <div class="form-outline mb-4">
                    <input type="password" name="password" id="form1Example2" class="form-control" value={user.password} onChange={handleInput} autoComplete="off" required />
                    <label class="form-label" for="form1Example2">Password</label>
                </div>

                <div class="form-outline mb-4">
                    <input type="number" name="phone" id="form1Example1" class="form-control" value={user.phone} onChange={handleInput} autoComplete="off" required />
                    <label class="form-label" for="form1Example1">phone</label>
                </div>

                <div class="row mb-4">
                    <div class="col d-flex justify-content-center">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="" id="form1Example3" checked />
                            <label class="form-check-label" for="form1Example3"> Remember me </label>
                        </div>
                    </div>


                </div>


                <button type="submit" name='signup' value="register" class="btn btn-primary btn-block">Register</button>
            </form>
        </div>
    )
}

export default SignUp
import React from 'react'
import { useState, useEffect } from 'react';
import { Col, Button, Row, Container, Card, Form } from "react-bootstrap";
import { Link, useNavigate } from "react-router-dom";
import axios from 'axios';
import jwt_decode from "jwt-decode";


export const SignIn = () => {
  const navigate = useNavigate();
  // const [email, setEmail] = useState('');
  // const [password, setPassword] = useState('');
  const [user, setUser] = useState({
    email:"",
    password:""
  })
  
console.log(user)
  const logIn = (e) => {
    e.preventDefault();
    /* axios api */
   const response = axios.post("http://localhost:3500/sign-in",user)
   .then((response) => {
   
    if (response.data.success === true) {
     alert(response.data.message);
      localStorage.setItem('token',response.data.token);
      console.log("login succss");
      navigate("/Usergallery");
    }
    else {
      console.log("login failed");
    }
    console.log(response)
   })
   .catch((error) => {
    console.log(error)
   })
  }
  


  return (
    <div>
      <Container>
        <Row className="vh-100 d-flex justify-content-center align-items-center">
          <Col md={8} lg={6} xs={12}>
            <div className="border border-3 border-primary"></div>
            <Card className="shadow">
              <Card.Body>
                <div className="mb-3 mt-md-4">
                  <h2 className="fw-bold mb-2 text-uppercase ">Brand</h2>
                  <p className=" mb-5">Please enter your login and password!</p>
                  <div className="mb-3">
                    <Form method='POST' onSubmit={logIn}>
                      <Form.Group className="mb-3" controlId="formBasicEmail">
                        <Form.Label className="text-center" aria-required>
                          Email address
                        </Form.Label>
                        <Form.Control type="email" placeholder="Enter email" name='email' value={user.email} onChange={(e) =>   setUser({...user, [e.target.name]:e.target.value})} required />
                      </Form.Group>

                      <Form.Group
                        className="mb-3"
                        controlId="formBasicPassword"
                      >
                        <Form.Label aria-required>Password</Form.Label>
                        <Form.Control type="password" placeholder="Password" name='password' value={user.password} onChange={(e) =>   setUser({...user, [e.target.name]:e.target.value})} required />
                      </Form.Group>
                      <Form.Group
                        className="mb-3"
                        controlId="formBasicCheckbox"
                      >
                        <p className="small">
                          <a className="text-primary" href="#!">
                            Forgot password?
                          </a>
                        </p>
                      </Form.Group>
                      <div className="d-grid">
                        <Button variant="primary" type="submit" value="logiIn" >
                          Login
                        </Button>
                      </div>
                    </Form>
                    <div className="mt-3">
                      <p className="mb-0  text-center">
                        Don't have an account?{" "}
                        {/* <Link to="signup">Sign Up</Link> */}
                        <Link to='./signup' className="text-primary fw-bold">Sign Up</Link>
                        {/* <a href='./Signup'>Signup</a> */}
                      </p>
                    </div>
                  </div>
                </div>
              </Card.Body>
            </Card>
          </Col>
        </Row>
      </Container>
    </div>
  );
}
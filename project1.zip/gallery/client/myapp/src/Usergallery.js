import React from 'react'
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import axios from 'axios';
import { useState, useEffect } from 'react';
import jwt_decode from "jwt-decode";




function Usergallery() {

  // const [userId, setUserId] = useState(localStorage.getItem('userId'));
  const [Image, setImage] = useState('');
  const [contents, setContents] = useState([]);

  const UploadImage = (e) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append("UploadedImage", Image);
    const decode = jwt_decode(localStorage.getItem('token'));
    console.log("upload", decode);
    formData.append("userId", decode.userId);
    axios.post('http://localhost:3500/create-gallery', formData, {
      headers: {
        'Content-type': "multipart/form-data"
      }
    })
      .then((res) => {
        console.log(res)

      })
      .catch((error) => {
        console.log(error);
      })
  }

  const handleFileChange = (e) => {
    console.log(e.target.files[0])
    setImage(e.target.files[0]);
  }
  console.log("image: ", Image);

  const fetchContents = async () => {
    const decode = jwt_decode(localStorage.getItem('token'));
    const { data } = await axios.get(
      `http://localhost:3500/get-content?userId=${decode.userId}`, {
      // headers: {
      //   Authorization: localStorage.getItem('token')
      // }
    }
    );

    const contents = data.content;
    setContents(contents);
    console.log(data);
  };

  useEffect(() => {
    fetchContents();
  }, []);

  return (
    <>
      <div>
        <Navbar bg="light" variant="light">
          <Container>
            <Navbar.Brand href="#home">UserGallery</Navbar.Brand>
            <Nav className="me-auto">
              <Nav.Link href="#home">Home</Nav.Link>
              <Nav.Link href="#features">Profile</Nav.Link>
            </Nav>
          </Container>
        </Navbar>
        <br></br>
        <form onSubmit={UploadImage}>
          <input type="file" name="avatar" onChange={handleFileChange} />
          <button>submit</button>
        </form>
      </div>
      <div className='container row my-4'>
        {contents.length > 0 && contents.map((contents) => (
          <div className='col-4'>
            <img
              src={contents.Image}
              className='img-fluid'
            />
          </div>
        ))
        }
      </div>

    </>
  )
}

export default Usergallery
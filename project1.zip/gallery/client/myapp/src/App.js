import './App.css';
import { SignIn } from './Signin';
import SignUp from './Signup';
import Usergallery from './Usergallery';
import { BrowserRouter, Routes, Route } from "react-router-dom";

function App() {
  return (
    <div className="App">
      <BrowserRouter>
      <Routes>
        <Route path="/" element={<SignIn  />} />
          {/* <Route index element={<SignIn />} /> */}
          <Route path="/Signup" element={<SignUp />} />
          <Route path="/Usergallery" element={<Usergallery />} />
      </Routes>
    </BrowserRouter>
    
    </div>
  );
}

export default App;

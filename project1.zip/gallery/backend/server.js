require('dotenv').config();
const express = require('express');
const app = express();
require('./Database/db');
const path = require("path")

const bodyparser = require('body-parser');
const cors = require('cors');


const swaggerUi = require('swagger-ui-express');
const swaggerDocs = require('./API_Document/swagger.json');

const PORT = process.env.PORT;

app.use(cors());

//to mnake upload folder public
app.use("/uploads", express.static("uploads"));


app.use(bodyparser.urlencoded({ extended: true }))
app.use(bodyparser.json())
app.use('/api',swaggerUi.serve, swaggerUi.setup(swaggerDocs));


app.use(require('./routes/route'));


app.listen(PORT, function (err) {
    if (err) console.log(err);
    console.log("Server listening on PORT", PORT);
  
});
const gallModel = require('../Models/galleryModel');


exports.createGall = async (req, res) => {
    try {
        const { userId } = req.body;
        console.log("Req.file:", req.file)
        const path = req.file.path;
        console.log("path: ", path);
        const seq = await gallModel.create({ userId, Image: "http://localhost:3500/" + path});
        res.json({ seq })
        console.log(seq)
    } catch (error) {
        console.log(error)
    }
}

exports.getContent = async(req, res) => {
    try {
        const data  = await gallModel.findAll({where:{userId:req.query.userId}});
        res.status(201).json({content : data});
    } catch (error) {
        console.log(error)
    }
}
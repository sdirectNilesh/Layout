const userModel = require('../Models/userModel');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');


exports.signup = async (req, res) => {
    console.log(req.body);
    
    const salt = await bcrypt.genSalt(10);
    var usr = {
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        email: req.body.email,
        password: await bcrypt.hash(req.body.password, salt),
        phone: req.body.phone
    };
   
    created_user = await userModel.create(usr);
    res.status(201).json({success:true, created_user, message: "Registration successful"});
}
exports.signin = async (req, res) => {
    // console.log(req.body);
    const userRes = await userModel.findOne({ where: { email: req.body.email  } })
    const isPasswordVerified = bcrypt.compareSync(req.body.password , userRes.password);

    if (isPasswordVerified) {
        const token = jwt.sign({ userId: userRes.id, email: userRes.email }, "secrete", { expiresIn: "1h" });
        res.json({ success:true, userdata: userRes, token, message:"Login successfully!" })
    } else {
        res.json({ message: "invalid credentials!" })
    }
}

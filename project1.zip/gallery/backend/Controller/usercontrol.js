const userModel = require('../Models/userModel');

exports.createUser = async(req, res) => {
    const {firstName, lastName, email, password, phone} = req.body;
    console.log(req.body);
    const seq = await userModel.create({firstName, lastName, email, password, phone});
    res.json({seq})
    console.log(seq)
}
exports.getUser = async(req, res) => {
    const seq = await userModel.findAll();
    res.json({seq})
    console.log(seq)
}


exports.updateUser = async(req, res) => {
    const {firstName, lastName, email, password, phone} = req.body;
    const seq = await userModel.update({firstName, lastName, email, password, phone},
        {
            where: {
                id: req.params.id
            }
        });
    res.status(200).json({seq: seq})
    console.log(seq)
}

exports.deleteUser = async(req, res) => {
    const seq = await userModel.destroy(
        {
            where: {
                id: req.params.id
            }
        });
    res.status(200).json({seq: seq})
    console.log(seq)
}
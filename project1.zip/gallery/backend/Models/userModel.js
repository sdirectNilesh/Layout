const {DataTypes} = require("sequelize")
const sequelize = require("../Database/db")

const Niluser_obj =  sequelize.define('Niluser_obj', {
    // Model attributes are defined here
    firstName: {
        type: DataTypes.STRING,
        allowNull: false
      },
      lastName: {
        type: DataTypes.STRING
      },
      email: {
        type: DataTypes.STRING,
        allowNull: false
      },
      password: {
        type: DataTypes.STRING,
        allowNull: false
      },
      phone: {
        type: DataTypes.STRING,
    
      }
      
})

module.exports = Niluser_obj;
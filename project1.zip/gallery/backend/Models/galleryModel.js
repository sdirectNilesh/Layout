const { Sequelize, DataTypes } = require("sequelize")
const sequelize = require("../Database/db")

const Nilgall_obj = sequelize.define('Nilgall_obj', {
    // Model attributes are defined here
    userId: {
        type: DataTypes.STRING,
    },
    Image: {
        type: DataTypes.STRING

    },
})
module.exports = Nilgall_obj;
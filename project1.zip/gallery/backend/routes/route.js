const express = require('express');
const {createUser, updateUser, deleteUser, getUser} = require('../Controller/usercontrol');
const { signup, signin } = require('../Controller/signup.controller');
const { userValidation } = require('../middleware/user.validate');
const router = express.Router();
const {createGall, getContent} = require('../Controller/gallerycontrol');
const upload = require('../middleware/gallery.multer');



router.post('/create-user', createUser);
router.post('/sign-up',userValidation, signup);
router.post('/sign-in', signin);

router.post('/create-gallery', upload.single('UploadedImage',4),createGall);

router.get('/get-content', getContent);

router.get('/get-user',getUser);

router.patch('/update-user/:id', updateUser);

router.delete('/delete-user/:id', deleteUser);



module.exports = router;
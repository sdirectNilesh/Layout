
const { Sequelize } = require('sequelize');

const sequelize = new Sequelize(process.env.DATABASE, process.env.USER_NAME, process.env.USER_PASSWORD, {
    host: process.env.HOST,
    logging: false,
    dialect: process.env.DIALECT
    
});
sequelize.authenticate().then(async () => {
    console.log("db connected")
    await sequelize.sync()
}).catch((e) => {
    console.log(e)
})

module.exports = sequelize;
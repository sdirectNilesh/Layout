import * as Yup from "yup"; 

const sigupSchema = Yup.object({
    name: Yup.string().required("please provide ypur name"),
    email: Yup.string().email().required("please provide your email"),
    password: Yup.string().min(6).required("please provide password you want"),
})

const loginSchema = Yup.object({
    email: Yup.string().email().required("please provide your email"),
    password: Yup.string().min(6).required("please provide password you want"),
})

export {sigupSchema, loginSchema}
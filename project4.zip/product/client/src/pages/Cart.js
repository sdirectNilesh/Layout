import React, { useEffect, useState, useReducer } from 'react'
import { Col, Button, Row, Form, Card, Container } from "react-bootstrap"
import axios from 'axios'
import Table from 'react-bootstrap/Table';
import Dropdown from 'react-bootstrap/Dropdown';
import jwt_decode from "jwt-decode";
import { Await, Link, useNavigate } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import { ToastContainer, toast } from 'react-toastify';


const reducer = (state, action) => {
    switch (action.type) {
        case "INCREMENT":
            return { ...state, count: state.count + 1 }
        case "DECREMENT":
            return { ...state, count: state.count - 1 }
        case "input":
            return { ...state, num: action.payload }
    }
    return state
}

function Cart() {


    const decode = jwt_decode(localStorage.getItem('token'));
    const [userId, setUserId] = useState(decode.userId);
    const [products, setProducts] = useState([]);
    const [selectedProduct, setSelectedProduct] = useState(null);
    const [productId, setProductId] = useState(null);
    const [count, setCount] = useState(0);
    const [price, setPrice] = useState([])
    const [totalPrice, setTotalPrice] = useState(0);
    const navigate = useNavigate();
    const [state, dispatch] = useReducer(reducer)


    const fetchCartProducts = async () => {
        const decode = jwt_decode(localStorage.getItem('token'));
        console.log("decode: ", decode);
        const { data } = await axios.get(
            `http://localhost:5001/get-cart/${decode.userId}`
        );
        const products = data.product;

        setProducts(products);

        console.log("data: ", products);
    };

    useEffect(() => {
        fetchCartProducts();
    }, []);

    const add = async(product) => {
        const res = await axios.post("http://localhost:5001/add", {
          productId: product,
          userId: userId
        })
        console.log("add", res);
        fetchCartProducts();
      }
    
      const sub = async (product) => {
        const res = await axios.post("http://localhost:5001/sub", {
          productId: product,
          userId: userId
        })
        console.log("sub", res);
        fetchCartProducts();
      }

    const grandToatal = () => {
        let price = products.map((product) => {
            return product.count * product.Nilproduct_obj.productPrice;
        })
        // console.log("total: ", totalPrice)
        setPrice(price)
    }

    useEffect(() => {
        grandToatal()
    }, [products])


    useEffect(() => {
        let sum = 0;
        price.forEach(items => {
            sum += items;

        });
        setTotalPrice(sum);
    }, [price])
    console.log("products: ", products)

    const placeOrder = async(order) => {

        console.log("order: ", order)
        if (order.length > 0) {
            const response = await axios.post('http://localhost:5001/add-order',
                {
                    data: order
                }
            ).then((response) => {
                console.log("response", response);
                if (response.data.success == true) {
                    toast.success("Order Successful", {
                        position: "top-right",
                        autoClose: 5000,
                        hideProgressBar: false,
                        closeOnClick: true,
                        pauseOnHover: true,
                        draggable: true,
                        progress: undefined,
                        theme: "light",
                    })
                    // alert(response.data.message);
                    setTimeout(() => {
                        navigate("/product/order");
                    }, 3000);
                    console.log("cart success");
                }

            }).catch(() => {
                console.log("err");
            });
        }
        else {
            toast.error("Please add a product in your");
            console.log("No Product In Your Cart ")
        }
    }

    const removeItem = async (id) => {
        try {
            const { data } = await axios.delete(
                `http://localhost:5001/remove-item/${id}`
            )
            fetchCartProducts();
        } catch (error) {
            console.log("errror at order deletion: ", error)
        }
    }

    const gotoOrder = () => {
        navigate("/product/pay");
    }
    const backtoProduct = () => {
        navigate("/product");
    }


    return (

        <div>
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <a class="navbar-brand" href="#">Cart</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div className='back-btn' style={{ marginLeft: "83%", width: "20%" }} >
                    <Button className='btn' onClick={backtoProduct}>Back</Button>
                </div>

                <div className='order-btn' style={{ marginRight: "0%", width: "20%" }} >
                    <Button className='btn' onClick={gotoOrder}>Order</Button>
                </div>

            </nav>
            <br></br>
            <Table class="table" >
                <thead>
                    <tr>
                        <th scope="col">Product</th>
                        <th scope='col'>Category</th>
                        <th scope="col">Count</th>
                        <th scope='col'>Total Price</th>
                    </tr>
                </thead>
                <tbody >
                    {products?.length > 0 && products.map((product) => (

                        <tr>
                            <td>{product.Nilproduct_obj.product1}</td>
                            <td>{product.Nilproduct_obj.category}</td>
                            <button className="quantity-right-plus btn btn-success btn-number" onClick={() => { add(product.Nilproduct_obj.productId) }}> + </button>
                               <td>{product.count}</td>
                            <button className="quantity-left-minus btn btn-danger btn-number" onClick={() => { sub(product.Nilproduct_obj.productId) }} > - </button>
                           
                            {/*                         
                            <td>  <input type="number" value={state.product.count} onChange={(e) => dispatch({ type: "input", payload: e.target.value })}></input>
                                  <button onClick={() => dispatch({ type: "INCREMENT" })} >Increment</button>
                                  <button onClick={() => dispatch({ type: "DECREMENT" })}>Decrement</button>
                            </td> */}
                            <td>{product.count * product.Nilproduct_obj.productPrice}</td>
                            <Button variant="danger" style={{ marginRight: "1.6%", width: "40%", marginBottom: "3px" }} onClick={() => { removeItem(product.id) }}>Remove From Cart</Button>
                        </tr>

                    ))
                    }
                </tbody>
            </Table>
            <div>
                <p>Total: {totalPrice}</p>
                <Button className='btn' style={{ marginRight: "1.6%", width: "20%" }} onClick={() => { placeOrder(products) }}>Order Now</Button>
                <ToastContainer />
            </div>
        </div >
    )
}

export default Cart;
import React, { useEffect, useState, useMemo } from 'react'
import { Col, Button, Row, Form, Card, Container, Pagination } from "react-bootstrap"
import axios from 'axios'
import Table from 'react-bootstrap/Table';
import Dropdown from 'react-bootstrap/Dropdown';
import { ToastContainer, toast } from 'react-toastify';
import jwt_decode from "jwt-decode";
import { Link, useNavigate } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';


function Product() {

    const decode = jwt_decode(localStorage.getItem('token'));
    const [userId, setUserId] = useState(decode.userId);
    const [products, setProducts] = useState([]);
    const [selectedProduct, setSelectedProduct] = useState(null);
    const [productId, setProductId] = useState(null);
    const [count, setCount] = useState(1);
    const navigate = useNavigate();
    console.log("products: ", products[0])

    const fetchAllProducts = async () => {

        const { data } = await axios.get(
            'http://localhost:5001/get-allproduct'
        );
        const products = data.product;
        setProducts(products);
        console.log("data: ", data);
    };

    useEffect(() => {
        fetchAllProducts();
    }, []);

    const userLogout = () => {

        const token = localStorage.clear();
        console.log("tok: ", token);
        if (!token) {
            navigate("/");
        }
    }

    const addtoCart = async (productId) => {
        console.log("productId: ", productId);

        const response = await axios
            .post('http://localhost:5001/add-cart',
                {
                    productId,
                    userId,
                    count,
                }
            ).then((response) => {
                console.log("datatatatta: ", response);
                if (response.data.success == true) {
                    toast.success("your product has been added to cart", {
                        position: "top-right",
                        autoClose: 5000,
                        hideProgressBar: false,
                        closeOnClick: true,
                        pauseOnHover: true,
                        draggable: true,
                        progress: undefined,
                        theme: "light",
                    })
                    // alert(response.data.message);
                    setTimeout(() => {
                        navigate("/product/cart");
                    }, 2000);
                    console.log("cart success");
                }

            }).catch(() => {
                console.log("err");
            });

    }

    const gotoCart = () => {
        navigate("/product/cart");
    }
    console.log("name: ", decode)


    return (
        <div>
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <a class="navbar-brand" href="#">Products</a>

                <div class="collapse navbar-collapse" id="navbarNavAltMarkup" style={{ marginRight: "2%" }}>
                    <div class="navbar-nav">
                        <Link to="/product/home">Home</Link>
                    </div>
                </div>
                <div class="collapse navbar-collapse" id="navbarNavAltMarkup" style={{ marginRight: "850px" }}>
                    <div class="navbar-nav">
                        <Link to="/product/home/updatepassword">UpdatePasword</Link>
                    </div>
                </div>
                <div className='user-name' style={{ marginLeft: "-6%" }}>
                    <h7>{decode.userName}</h7>
                </div>
                <div className='cart-btn' style={{ marginRight: "2.2%", width: "20%" }} >
                    <Button className='btn' onClick={gotoCart}>Cart</Button>
                </div>
                <div className='logout-btn' style={{ marginRight: "1.4%", marginLeft: "-1%", width: "8%" }} >
                    <Button className='btn' onClick={userLogout}>Logout</Button>
                </div>

            </nav>
            <br></br>
            <Table class="table" >
                <thead>
                    <tr>
                        <th scope="col">Index</th>
                        <th scope="col">BRAND</th>
                        <th scope='col'>Price</th>
                        <th scope='col'>Category</th>
                    </tr>
                </thead>
                <tbody >
                    {products?.length > 0 && products.map((product) => (

                        <tr>
                            <th scope="row">{product.productId}</th>
                            <td>{product.product1}</td>
                            <td>{product.productPrice}</td>
                            <td>{product.category}</td>

                            <td>
                                <Form.Group as={Col} controlId="formGridState">
                                    <Form.Select defaultValue="1" placeholder="Count" onChange={(e) => setCount(e.target.value)} required>
                                        <option value="1">1</option>
                                        <option value="2">2</option>
                                        <option value="3">3</option>
                                        <option value="4">4</option>
                                    </Form.Select>
                                </Form.Group>
                            </td>
                            <td><Button onClick={() => { addtoCart(product.productId) }} >Add To Cart</Button></td>
                            <ToastContainer />

                        </tr>
                    ))
                    }
                </tbody>
            </Table>
           
        </div >
    )
}

export default Product;
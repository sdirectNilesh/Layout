import { useState } from 'react';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import Cart from './Cart';


function HandleDelete() {
  const [show, setShow] = useState(false);
  const [confirmed, setConfirmed] = useState(false);

  const handleClose = () => setShow(false);
  const handleCancel = () => {
    setConfirmed(true);
    console.log("confirm: ", confirmed)
}
  const handleShow = () => setShow(true);

  return (
    <div>
      <Button variant="primary" onClick={handleShow}>
      Remove From Cart
      </Button>

      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Modal heading</Modal.Title>
        </Modal.Header>
        <Modal.Body>Woohoo, you are reading this text in a modal!</Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button variant="primary" onClick={handleCancel}>
            Save Changes
          </Button>
        </Modal.Footer>
        <Cart show={show} setShow={setShow} confirmed={confirmed} />
      </Modal>
      
    </ div>
  );
}

export default HandleDelete;
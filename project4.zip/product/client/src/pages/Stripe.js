import React, { useState } from 'react'
import StripeCheckout from 'react-stripe-checkout';


function Stripe() {
  const [show, setShow] = useState(false);
  const [confirmed, setConfirmed] = useState(false);

  const handleClose = () => setShow(false);
  const handleCancel = () => {
    setConfirmed(true);
    console.log("confirm: ", confirmed)
}
  const handleShow = () => setShow(true);
  let onToken = (token) => {
    fetch('/save-stripe-token', {
      method: 'POST',
      body: JSON.stringify(token),
    }).then(response => {
      response.json().then(data => {
        alert(`We are in business, ${data.email}`);
        console.log("payement: ", response)
      });
    });
  }
  return (
          <StripeCheckout
            token={onToken}
            stripeKey="pk_test_51OA5hCSFd5vjIva6XPc0LdA6RT4aAitOcWlom6UaXHiOJJXtmfXLqB1nhHA03as3vmaCkDA3aP5xt9JZ8VI7p6X000gHTuI8uh"
          />
        );
}

export default Stripe;
import React from 'react'
import { useState } from 'react'
import { Link, useNavigate } from "react-router-dom";
import { ToastContainer, toast } from 'react-toastify';
import axios from 'axios';
import { useFormik } from 'formik';
import { sigupSchema } from '../schema/schema';


const initialValues = {
  name: "",
  email: "",
  password: "",
}

function Signup() {

  const navigate = useNavigate();
  const {values, errors, touched, handleSubmit , handleBlur, handleChange} = useFormik({
    initialValues: initialValues,
    validationSchema:sigupSchema,
    onSubmit: ((values) => {
      const user = {
        name: values.name,
        email: values.email,
        password: values.password
      }
      axios.post("http://localhost:5001/sign-up",user )
      .then((response) => {
        if (response.data.success === true) {
          alert(response.data.message);
          console.log("Registration sucess");
          navigate("/");
        }
      })
      .catch((error) => {
        toast.error(error.response.data.error);
        navigate('/signup');
        console.log(error)
      })
    })
  })
 
 


  return (
    <div>
      <section class="vh-110" style={{ background: "#eee" }}>
        <div class="container py-5 h-80">
          <div class="row d-flex justify-content-center align-items-center h-0">
            <div class="col-8 col-md-6 col-lg-6 col-xl-5">
              <div class="card shadow-2-strong" style={{ border: "1rem" }}>
                <div class="card-body p-4 vh-90 text-center">

                  <h3 class="mb-3">Register</h3>

                  <div class="text-center">
                    <img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-login-form/lotus.webp"
                      style={{ width: "185px" }} alt="logo" />

                  </div>
                  <form onSubmit={handleSubmit} >
                    <div class="form-outline mb-4">
                      <input type="string" name="name" id="typeEmailX-2" class="form-control form-control-lg" onBlur={handleBlur} value={values.name} onChange={handleChange} />
                      <label class="form-label" for="typeEmailX-2">Name</label>
                    {errors.name&&touched.name?(
                      <p className='form-error' style={{color:"blue"}}>{errors.name}</p>
                    ):null}
                    
                    </div>


                    <div class="form-outline mb-4">
                      <input type="email" name="email" id="typeEmailX-2" class="form-control form-control-lg" onBlur={handleBlur} value={values.email} onChange={handleChange} />
                      <label class="form-label" for="typeEmailX-2">Email</label>
                      {errors.email&&touched.email?(
                      <p className='form-error' style={{color:"blue"}}>{errors.email}</p>
                    ):null}
                    </div>

                    <div class="form-outline mb-4">
                      <input type="password" name="password" id="typePasswordX-2" class="form-control form-control-lg" onBlur={handleBlur} value={values.password} onChange={handleChange} />
                      <label class="form-label" for="typePasswordX-2">Password</label>
                      {errors.password&&touched.password?(
                      <p className='form-error' style={{color:"blue"}}>{errors.password}</p>
                    ):null}
                    </div>

                    <button class="btn btn-primary btn-lg btn-block mb-3" type="submit" name="signup" value="register" >Signup</button>
                    <div class="d-flex align-items-center justify-content-center pb-4">
                      <p class="mt-10px mb-0 me-2">Have an account</p>
                      <Link to='/'>Login</Link>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

export default Signup
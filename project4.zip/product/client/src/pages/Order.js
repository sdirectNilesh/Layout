import React, { useEffect, useState } from 'react'
import { Col, Button, Row, Form, Card, Container } from "react-bootstrap"
import axios from 'axios'
import Table from 'react-bootstrap/Table';
import Dropdown from 'react-bootstrap/Dropdown';
import jwt_decode from "jwt-decode";
import { Await, Link, useNavigate } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';




function Order() {


  const decode = jwt_decode(localStorage.getItem('token'));
  const [userId, setUserId] = useState(decode.userId);
  const [products, setProducts] = useState([]);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [productId, setProductId] = useState(null);
  const [count, setCount] = useState(0);
  const [price, setPrice] = useState([])
  const [totalPrice, setTotalPrice] = useState(0);
  const navigate = useNavigate();


  const fetchOrderProducts = async () => {
    const decode = jwt_decode(localStorage.getItem('token'));
    console.log("decode: ", decode);
    const { data } = await axios.get(
      `http://localhost:5001/get-order/${decode.userId}`
    );
    const products = data.product;

    setProducts(products);
    console.log("data: ", products);
  };

  useEffect(() => {
    fetchOrderProducts();
  }, []);

  const grandToatal = () => {
    let price = products.map((product) => {
      return product.count * product.Nilproduct_obj.productPrice;
    })
    // console.log("total: ", totalPrice)
    setPrice(price)
  }

  useEffect(() => {
    grandToatal()
  }, [products])


  useEffect(() => {
    let sum = 0;
    price.forEach(items => {
      sum += items;

    });
    setTotalPrice(sum);
  }, [price])

  const cancelOrder = async (id) => {
    try {
      const { data } = await axios.delete(
        `http://localhost:5001/cancel-order/${id}`
      )
      fetchOrderProducts();
    } catch (error) {
      console.log("errror at order deletion: ", error)
    }
  }

  const backtoProduct = () => {
    navigate("/product/cart");
  }

  return (
    <div>
      <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="#">Order</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div className='back-btn' style={{ marginLeft: "83%", width: "20%" }} >
          <Button className='btn' onClick={backtoProduct}>Back</Button>
        </div>

      </nav>
      <br></br>
      <Table class="table" >
        <thead>
          <tr>
            <th scope="col">Product</th>
            <th scope='col'>Category</th>
            <th scope="col">Count</th>
            <th scope='col'>Total Price</th>
          </tr>
        </thead>
        <tbody >
          {products?.length > 0 && products.map((product) => (

            <tr>
              <td>{product.Nilproduct_obj.product1}</td>
              <td>{product.Nilproduct_obj.category}</td>
              <td>{product.count}</td>
              <td>{product.count * product.Nilproduct_obj.productPrice}</td>
              <Button variant="danger" style={{ marginRight: "1.6%", width: "40%", marginBottom: "3px" }} onClick={() => { cancelOrder(product.id) }}>Cancel Order</Button>
            </tr>

          ))
          }
        </tbody>
      </Table>
      <div>
        <p>Total: {totalPrice}</p>

      </div>
    </div >
  )
}

export default Order;
const { Sequelize } = require("sequelize")
const {DataTypes} = require("sequelize")
const sequelize = require("../Database/db")
const userModel = require("./userModel")

const Nilproduct_obj = sequelize.define('Nilproduct_obj', {
    // Model attributes are defined here
    productId: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true
    },
    userId: {
        type: DataTypes.STRING,
    },
    product1: {
        type: DataTypes.STRING,
        allowNull: false
    },
    productPrice: {
        type: DataTypes.STRING,
        allowNull: false
    },
    category: {
        type: DataTypes.STRING,
        defaultValue: "Electronics",
        allowNull:true
    }
})
userModel.hasMany(Nilproduct_obj,
    {foreignKey: "userId"}
    )

Nilproduct_obj.belongsTo(userModel,
    {foreignKey:"userId"})    

module.exports = Nilproduct_obj;
const express = require('express');
const app = express();
require('./Database/db');
const path = require("path");
const bodyparser = require('body-parser');
const cors = require('cors');
const PORT = 5001;
const stripe = require("stripe")("sk_test_51OA5hCSFd5vjIva6lmSwjiSHmXkaD1e2yqFTMKngcKq2YMDtYV6wz5aFtrIpcPtAdW4NCCLHWgzmEzlX0DI7vzeN00p1IjmcFc")

app.use(bodyparser.urlencoded({ extended: true }))
app.use(bodyparser.json())

app.use(cors());


app.use(require('./Routes/route'));


app.listen(PORT, function (err) {
    if (err) console.log(err);
    console.log("Server listening on PORT", PORT);
});
const Nilproductcart_obj = require('../Models/cartModel');
const userModel = require("../Models/userModel")
const Nilproduct_obj = require("../Models/prodModel")
const { Op } = require("sequelize");

exports.addtoCart = async (req, res) => {
    try {
        const cart = {
            productId: req.body.productId,
            userId: req.body.userId,
            count: req.body.count,
        };
        let user = await userModel.findByPk(cart.userId);
        let product = await Nilproduct_obj.findByPk(cart.productId);
        const existingItem = await Nilproductcart_obj.findOne({
            where: {
                userId: cart.userId,
              productId: cart.productId
            }
        });
        console.log("existing: ", existingItem);
        if (user && product && existingItem) {
            existingItem.count = cart.count;
            existingItem.save();
            return res.status(200).json({ success: true, product: existingItem, message: "Product is added to cart" });
        }
        else {
            let created_cart = await Nilproductcart_obj.create(cart);
            return res.status(200).json({ success: true, product: existingItem, message: "Product is added to cart" });   
        }

    } catch (error) {
        console.log(error)
        return res.status(400).json({ error: 'Missing required fields.' });
    }
}

exports.getCart = async (req, res) => {
    try {
        const userId = req.params.id
        const data = await Nilproductcart_obj.findAll({
            where: { userId: userId },
            include: [
                { model: Nilproduct_obj },
            ]
        });
        res.status(201).json({ product: data });
    } catch (error) {
        console.log("error at get cart: ", error)
    }
}

exports.removeItem = async (req, res) => {
    try {
        console.log("cartid: ", req.params.id)
        const cartId = req.params.id
        const order = await Nilproductcart_obj.findByPk(cartId);
        if (order) {
            const Destroyed_Cart = await Nilproductcart_obj.destroy({ where: { id: cartId } });
            return res.status(201).json({ product: Destroyed_Cart, message: "order cancelled" });
        }
    } catch (error) {
        console.log("error at cancelling order: ", error)
    }
}

exports.incInCart = async (req, res) => {
    const {productId, userId} = req.body

    try {
        const cart = await Nilproductcart_obj.findOne({
            where: {
                userId:userId,
                productId:productId
            }})


            if(cart){
                if(cart.count>=1){
                    
                    const product = await Nilproductcart_obj.update({ count:+(cart.count) + 1 },
                    {
                        where: {
                            productId:productId,
                            userId:userId
                        } } )
            
                    return res.status(200).json({success:true, product:product})
                }
            }

           
    } catch (error) {
        console.log(error);
    }
}

exports.decInCart = async (req, res) =>{
    const {productId, userId} = req.body

    try {
        const cart = await Nilproductcart_obj.findOne({
            where: {
                userId:userId,
                productId:productId
            }
        })

        if(cart){
            if(cart.count>1){
                const product = await Nilproductcart_obj.update({
                    count: cart.count-1
                },
                {
                    where: {
                        productId:productId,
                        userId:userId
                    }
                }
                )
                return res.status(200).json({success:true, product:product})
            }
        }
    } catch (error) {
        console.log(error);
    }
}
const Nilproductorder_obj = require('../Models/orderModel');
const userModel = require("../Models/userModel")
const Nilproduct_obj = require("../Models/prodModel")
const { Op } = require("sequelize");
const Nilproductcart_obj = require('../Models/cartModel');

exports.addtoOrder = async (req, res) => {
    try {

        const { data } = req.body
        console.log(req.body);


        {
           data && data.length > 0 && data.map(async (item) => {
                const order = await Nilproductorder_obj.create({
                    userId: item.userId,
                    productId: item.productId,
                    count: item.count,
                })
                const Destroyed_Cart = await Nilproductcart_obj.destroy({ where: { id: item.id } });
                return res.status(200).json({success: true, product: order });
            })
        }
    } catch (error) {
        return res.status(401).json({error: "You haven't added to your cart"});
        console.log(error)
    }
}

exports.getOrder = async (req, res) => {
    try {
        const userId = req.params.id
        const data = await Nilproductorder_obj.findAll({
            where: { userId: userId },
            include: [
                { model: Nilproduct_obj },
            ]
        });
        res.status(201).json({ product: data });
    } catch (error) {
        console.log("error at getting orderlist: ", error)
    }
}

exports.cancelOrder = async (req, res) => {
    try {
        console.log("orderid: ", req.params.id)
        const orderId = req.params.id
        const order = await Nilproductorder_obj.findByPk(orderId);
        if (order) {
            const Destroyed_Order = await Nilproductorder_obj.destroy({ where: { id: orderId } });
            return res.status(201).json({ product: Destroyed_Order, message: "order cancelled" });
        }
    } catch (error) {
        console.log("error at cancelling order: ", error)
    }
}
import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class RoomService {
  private _msgData = new BehaviorSubject<any>(null);

  private _receiverName = new BehaviorSubject<any>(null);


  constructor(private http: HttpClient) {}
  get msgData$() {
    return this._msgData.asObservable();
  }

  setMsgData(msgData: any) {
   
    this._msgData.next(msgData);
  }

  setReciever(data: any) {
   
    this._receiverName.next(data);
  }

  get receiverName$() {
    return this._receiverName.asObservable();
  }

  getActiveChat() {
    return this.http.get('http://localhost:5656/getActiveChat');
  }

  getIndividualChat(roomId: any) {
    this.http.get(
      `http://localhost:5656/getIndividualChat?roomId=${roomId}`
    ).subscribe({
      next: (newData) => {
        const data = newData
        console.log(data)
        // Assuming the response contains the new data you want to set
        this.setMsgData(newData);
      },
      error :(error) => {
        console.error('Error fetching individual chat:', error);
      }
  });
  }

  findRoom(data: any) {
    console.log("find",data)
    return this.http.get(`http://localhost:5656/findRoom?userId=${data.senderId}&receiverId=${data.receiverId}`);
  }

  clearRoomData(){
    console.log("clearRoom")
    this._msgData.complete();  // Completes the BehaviorSubject
    this._msgData = new BehaviorSubject<any>(null);
  }

  // setUnreadCount(data:any){
  //   console.log("data in set unread",data)
  //   const _dataH={
  //     userId : data
  //   }
  //   return this.http.get('http://localhost:5656/setUnreadCount',_dataH);
  // }

  setUnreadCount(data:any)
{
  const _data={
    userId :data
  }
  return this.http.post("http://localhost:5656/setUnreadCount",_data)
}
}

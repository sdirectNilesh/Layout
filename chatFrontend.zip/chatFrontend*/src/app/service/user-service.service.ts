import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserServiceService {

  constructor(private http : HttpClient) { }

signUp(data:any)
{
  return this.http.post("http://localhost:4009/signUp",data)
}

login(data:any)
{
  return this.http.post("http://localhost:4009/login",data)
}

getUserList()
{
  return this.http.get("http://localhost:4009/getUserList")
}

logout(data: any)
{
  const _data={
    userId :data
  }
  return this.http.post("http://localhost:4009/logout",_data)
}
}

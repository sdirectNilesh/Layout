import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { io } from 'socket.io-client';

@Injectable({
  providedIn: 'root',
})
export class SocketServiceService {
  socket: any;


  constructor() {
    this.socket = io('http://localhost:5656');
  }
  userId = localStorage.getItem('userId');
  receiverId = localStorage.getItem('receiverId');

  createConnnection() {
    this.socket.on('create_socket', (data: any) => {
      console.log({data});
      let _data;
      localStorage.setItem('socketId', data.socketId);
      if (data.socketId) {
        _data = {
          userId: this.userId,
          socketId: data.socketId,
        };
      }

      this.socket.emit('createconnection', _data);
      return data;
    });
    return;
  }

  sendMessage(data: any) {
    // console.log('receiver', this.receiverId);
    const _data = {
      senderId: this.userId,
      message: data.message,
      receiverId: this.receiverId,
    };
    this.socket.emit('message', _data);
  }

  receiveMessage(): Observable<any> {
    return new Observable((observer) => {
        this.socket.on('newMessage', (data: any) => {
          // console.log('receive', data);
          observer.next(data);
        });

      return () => {
        this.socket.off('newMessage'); // Unsubscribe when component is destroyed
      };
    })
  }
}

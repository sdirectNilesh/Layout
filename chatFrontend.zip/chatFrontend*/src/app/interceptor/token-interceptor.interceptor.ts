// my-interceptor.interceptor.ts
import { Injectable } from '@angular/core';
import {
  HttpEvent,
  HttpHandler,
  HttpInterceptor,
  HttpRequest,
  HttpResponse,
  HttpErrorResponse,
} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';

@Injectable()
export class TokenInterceptorInterceptor implements HttpInterceptor {
  intercept(
    request: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    // Add headers to the request
    const token = localStorage.getItem("token") || ""
    const modifiedRequest = request.clone({
      setHeaders: {
        Authorization: `Bearer ${token}`,
      },
    });

    // Pass the modified request to the next handler
    return next.handle(modifiedRequest).pipe(
      tap((event: HttpEvent<any>) => {
        if (event instanceof HttpResponse) {
          // Handle successful responses
          // console.log('Response received:', event);
        }
      }),
      catchError((error: any) => {
        // Handle errors
        if (error instanceof HttpErrorResponse) {
          console.error('HTTP Error:', error);
        } else {
          console.error('Other error:', error);
        }

        // Pass the error along to be handled by the application
        return throwError(error);
      })
    );
  }
}

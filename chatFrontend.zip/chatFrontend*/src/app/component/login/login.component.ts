import { Component } from '@angular/core';
import {FormBuilder,FormGroup,Validators,FormControl} from '@angular/forms'
import { Router, ActivatedRoute } from '@angular/router';
import { UserServiceService } from 'src/app/service/user-service.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  loginForm!:FormGroup

  constructor(private fb:FormBuilder,
    private router:Router,
    private userService:UserServiceService)
  {
  
  }
  ngOnInit():void{
    this.loginForm=this.fb.group({
      email: [
        '',
        [
          Validators.required,
          Validators.email,
          Validators.pattern(
            /^.[a-zA-Z0-9]{1,256}@.[a-zA-Z0-9]{1,256}\.[a-zA-Z]{1,4}$/
          ),
        ],
      ],
      password: ['', [Validators.minLength(6),
        Validators.required,
        Validators.pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()-_+=])[A-Za-z\d!@#$%^&*()-_+=]{6,}$/)
      ]],
    })


    
  
  
}
markFormGroupTouched(formGroup: FormGroup) {
  Object.values(formGroup.controls).forEach((control) => {
    if (control instanceof FormGroup) {
      this.markFormGroupTouched(control);
    } else {
      control.markAsTouched();
    }
  });
}

hasError(controlName: string, errorType: string): any {
  const control = this.loginForm.get(controlName);
  return control?.touched && !!control?.errors?.[errorType]
}

onSubmit():void{

 this.userService.login(this.loginForm.value).subscribe((res:any)=>
 {
  // console.log(res)
  if (res.statusCode === 200) {
    localStorage.setItem("userId",res.data._id)
    localStorage.setItem("token",res.token)
    this.router.navigate(['/chat']);
  }
 })

}

}

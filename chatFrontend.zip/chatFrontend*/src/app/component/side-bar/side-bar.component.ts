import { Component } from '@angular/core';
import { UserServiceService } from 'src/app/service/user-service.service';
import { CommonModule } from '@angular/common';
import { RoomService } from 'src/app/service/room.service';
import { ThisReceiver } from '@angular/compiler';

@Component({
  selector: 'app-side-bar',
  templateUrl: './side-bar.component.html',
  styleUrls: ['./side-bar.component.css'],
})
export class SideBarComponent {
  users: any;
  receiverId: any;
  activeChat: any;
  msgData: any;
  userId = localStorage.getItem('userId');

  constructor(
    private userService: UserServiceService,
    private roomService: RoomService
  ) {
    this.userService.getUserList().subscribe((res: any) => {
      // console.log('res', res);
      this.users = res?.data;
      // console.log('users', this.users);
    });

    this.roomService.getActiveChat().subscribe((res: any) => {
      //  console.log("active chat",res)
      this.activeChat = res?.data;
      console.log("active chat",this.activeChat)
    });
  }

  ngOnInit() {}

  handleReceiver(data: any) {
    this.receiverId = data._id;
    console.log("user",data)
    localStorage.setItem('receiverId', this.receiverId);
    this.roomService.setReciever(data)
    const roomData=this.activeChat.filter((chat:any)=>chat.receiverInfo?._id==data?._id)
    console.log("roomData",roomData)
    if(roomData.length)
    {
      this.roomService.getIndividualChat(roomData[0]?._id)
    }
    else
    {
      console.log("else")
      this.roomService.setMsgData([])
    }
    
  }

  count: number = 0;
  handleReceiverA(data: any) {
   
    const receiver = localStorage.getItem('receiverId');
    this.receiverId = data?.receiverInfo?._id;
    this.roomService.setReciever(data?.receiverInfo)
    if (receiver != this.receiverId) {
      localStorage.setItem('receiverId', this.receiverId);
      this.roomService.getIndividualChat(data._id);
      
    }
  }
}

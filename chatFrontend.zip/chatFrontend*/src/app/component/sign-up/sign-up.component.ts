import { Component } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  Validators,
  FormControl,
  AbstractControl
} from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { UserServiceService } from 'src/app/service/user-service.service';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent {
  signUpForm!: FormGroup;
  constructor(
    private fb: FormBuilder,
    private router: Router,
    private userService:UserServiceService
  ) {}


  ngOnInit(): void {
    this.signUpForm = this.fb.group({
      userName: [
        '',
        [
          Validators.required,
          Validators.minLength(3),
          Validators.maxLength(20),
          Validators.pattern(/^[a-zA-Z]+(([',. -][a-zA-Z ])?[a-zA-Z]*)*$/),
        ],
      ],
      email: [
        '',
        [
          Validators.required,
          Validators.email,
          Validators.pattern(
            /^.{1,256}@.{1,256}\.[a-zA-Z]{1,4}$/
          ),
        ],
      ],
      password: ['', [Validators.minLength(6),
        Validators.required,
        Validators.pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()-_+=])[A-Za-z\d!@#$%^&*()-_+=]{6,}$/)
      ]],
      repeatPassword: ['', [Validators.required]],
    },{
      validators: this.passwordMatchValidator
    });
  }

  passwordMatchValidator(control: AbstractControl): { [key: string]: boolean } | null {
    const password = control.get('password')?.value;
    const confirmPassword = control.get('repeatPassword')?.value;
  
    if (password !== confirmPassword) {
      control.get('repeatPassword')?.setErrors({ 'passwordMismatch': true });
      return { 'passwordMismatch': true };
    } else {
      control.get('repeatPassword')?.setErrors(null);
      return null;
    }
  }

  markFormGroupTouched(formGroup: FormGroup) {
    Object.values(formGroup.controls).forEach((control) => {
      if (control instanceof FormGroup) {
        this.markFormGroupTouched(control);
      } else {
        control.markAsTouched();
      }
    });
  }

  hasError(controlName: string, errorType: string): any {
    const control = this.signUpForm.get(controlName);
    return control?.touched && !!control?.errors?.[errorType]
}


onSubmit()
{
  this.userService.signUp(this.signUpForm.value).subscribe((res:any)=>{
    // console.log(res)
    if (res.statusCode === 201) {
      this.router.navigate(['/']);
    }
  })
}
}

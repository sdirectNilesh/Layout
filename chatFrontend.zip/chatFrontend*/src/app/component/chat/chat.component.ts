import { CdkVirtualScrollViewport } from '@angular/cdk/scrolling';
import { ChangeDetectorRef, Component, Input, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import io from 'socket.io-client';
import { RoomService } from 'src/app/service/room.service';
import { SocketServiceService } from 'src/app/service/socket-service.service';
import { UserServiceService } from 'src/app/service/user-service.service';

@Component({
  selector: 'app-chat',
  templateUrl: './chat.component.html',
  styleUrls: ['./chat.component.css'],
})
export class ChatComponent {
  message: string = '';
  messageData: any = [];
  userId = localStorage.getItem('userId');
  receiver = localStorage.getItem('receiverId');
  receiverData: any;
  unread=0
  readMsg:any
  readMsgId:any


  @ViewChild(CdkVirtualScrollViewport)

  private virtualScroll: CdkVirtualScrollViewport | undefined;

  constructor(
    private socketService: SocketServiceService,
    private roomService: RoomService,
    private userService: UserServiceService,
    private router: Router ,
    private cdr: ChangeDetectorRef 
  ) {
    this.socketService.createConnnection();
    localStorage.removeItem("receiverId")
    this.roomService.msgData$.subscribe((msgData) => {

      if (msgData) {
        this.messageData = [];
        msgData?.data?.map((item: any) => {
          this.messageData.push(item);
        });
      }

      // this.roomService.
      this.unread=this.messageData[0]?.unreadCount
      console.log('messageData', this.messageData);
      console.log('unread', this.unread);
      this.readMsg=this.messageData[this.messageData.length-this.unread-1]

      console.log("readMsg",this.readMsg)

      this.readMsgId=this.readMsg?.messages?._id
      console.log("readMsgId",this.readMsgId)


      this.scrollToUnread()
      this.unread=0;
        this.roomService.setUnreadCount(this.messageData[0]?._id).subscribe((res)=>{
          console.log(res)
        })
      
    });

    this.roomService.receiverName$.subscribe((receiver) => {
      this.receiverData = receiver;
    });
  }

  ngOnInit() {
    this.socketService.receiveMessage().subscribe((res: any) => {
      console.log('receive', res);

      const receiverId = res.data.receiverId;
     
      let receive = localStorage.getItem("receiverId")
      console.log("receive",receive)
      const roomIndex = this.messageData.findIndex((room:any) => room.messages.receiver === receiverId);
      console.log("roomINdex",roomIndex)
      if(receiverId==receive)
      {
      this.messageData?.push(res.data);

      }
    });

    
  }

  sendMessage() {
    const data = {
      userId: this.userId,
      message: this.message,
      receiver: this.receiver,
    };
    this.messageData?.push(data);
    console.log('messagedata after sending msg', this.messageData);
    this.socketService.sendMessage(data);

    this.message=''
  }

  logout() {
    this.userService.logout(this.userId).subscribe((res) => {
      console.log(res);
    });
    localStorage.clear();

    this.router.navigate(['/']);
  }

  scrollToUnread() {
    console.log("scroll to ");
    if (this.unread > 0 && this.readMsgId) {
      const unreadIndex = this.messageData.findIndex(
        (msg: any) => msg.messages?._id === this.readMsgId
      );
      console.log("unreadIndex", unreadIndex);
      if (unreadIndex !== -1) {

       
        setTimeout(()=>{
          this.virtualScroll?.scrollToIndex(unreadIndex-1);
        },0)
        
        
     
      }
    }
    else if( this.unread == 0)
    {
      const length = this.messageData.length
      setTimeout(()=>{
        this.virtualScroll?.scrollToIndex(length);
      },0)
    }
  }
  
}

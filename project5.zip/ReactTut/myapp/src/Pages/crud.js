import React, { Children, useState } from 'react'


function Crud() {
    const [firstName, setFirstName] = useState('');
    const [lastName, setLastName] = useState('');
    const [age, setAge] = useState('');
    const [list, setList] = useState([]);
    
    const addList = (e) => {
        e.preventDefault();
        const data = {firstName, lastName, age};
        list.push(data);
        setList([...list])
        console.log("list: ", list)
    }

    const dropItem = (item) => {
        const newList = list.filter((data) => {
            return (data!=item)
        })
        setList(newList)
        console.log("deleted: ", newList)
    }

    const editItem = (item) => {
       const newList = list .filter((data) => {
        return (data.age===item.age)
       })
    }
  return (
    <>
     <div>CRUD</div>
     <div>
        <form method='submit'>
            <input value={firstName} type="text" placeholder='firstName' onChange={(e) => {setFirstName(e.target.value)}}></input>
            <input value={lastName} type="text" placeholder='lastName' onChange={(e) => {setLastName(e.target.value)}}></input>
            <input value={age} type="number" placeholder='age' onChange={(e) => {setAge(e.target.value)}}></input>
            <button onClick={addList}>submit</button>
        </form>
     </div>
     <div>
        {list.length>0 && list.map((item, index) => (
            <ul>
                <li>Index: {index}</li>
                <li>firstName: {item.firstName}</li>
                <li>lastName: {item.lastName}</li>
                <li>age: {item.age}</li>
                <button onClick={() => {dropItem(item)}}>Delete</button>
                <button onClick={() => {editItem(item)}}>Edit</button>
            </ul>
        ))}
     </div>
    </>
  )
}

export default Crud
import React from 'react'
import UseReduce from './UseReduce';
import UseState from './UseState';
import Product from './Product';
import {
    BrowserRouter,
    Route,
    Link,
    Routes
} from "react-router-dom";
import Crud from './crud';
import HandleProduct from '../redux/HandleProduct';



function Home() {
    return (
        <>
            <div>
                <h3>Home</h3>
            </div>
            <BrowserRouter>
                <div>
                    <Routes>
                        <Route path='/home' element={<Home />} />
                        <Route path='/home/handleproduct' element={<HandleProduct />}/>
                        <Route path="/home/usereduce" element={<UseReduce />} />
                        <Route path="/home/usestate" element={<UseState />} />
                        <Route path="/home/product" element={<Product />} />
                        <Route path= "/home/crud" element={<Crud />} />
                    </Routes>
                </div>
            </BrowserRouter>


        </>
    )
}

export default Home
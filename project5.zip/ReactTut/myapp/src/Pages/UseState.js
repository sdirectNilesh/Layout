import React, { useEffect, useState } from 'react'

function UseState() {
    const[count, setCount] = useState();
    const[num, setNum] = useState('');
   
    const [list, setList] = useState(["book1, book2, book3"]);
    
    
    const AddTo = () => {
        setCount(count + +num);
    }
    const SubtractFrom = () => {
        setCount(count - +num);
    }
    const addOne = () => {
      list.push('book4');
      setList(list);
      console.log("list: ", list)
    }

    
   
  return (
    <>
    <div>UseState</div>
    <div>
      <p>TotalCount: {count}</p>
      <input type="number" value={num} onChange = {(e) => setNum(e.target.value)}></input>
      <button onClick={AddTo}>Add</button>
      <button onClick={SubtractFrom}>Subtract</button>
    </div>
    {list.length>0 && list.map((item) => (
      <ul>
        <li>{item}</li>
      </ul>
    ))
    }
    <button onClick={addOne}>add</button>
    </>
  )
}

export default UseState
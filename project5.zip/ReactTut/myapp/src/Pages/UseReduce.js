import React, { useReducer, useState } from 'react'

const reducer = (state, action) => {
    switch (action.type) {
        case "INCREMENT":
            return { ...state, count: state.count + 1 }
        case "DECREMENT":
            return { ...state, count: state.count - 1 }
        case "ADD":
            return { ...state, count: state.count + Number(action.payload) }
        case "SUB":
            return { ...state, count: state.count - +action.payload }
        case "input":
            return { ...state, num:action.payload }
    }
    return state
}

function UseReduce() {
  
    const [state, dispatch] = useReducer(reducer, { count: 0 , num: 0})

    return (
        <div>
            <h1>usereduce</h1>
            <h1>result:{state.count}</h1>
            <input type="number" value={state.num} onChange={(e) => dispatch({ type: "input", payload:e.target.value })}></input>
            <button onClick={() => dispatch({ type: "INCREMENT" })} >Increment</button>
            <button onClick={() => dispatch({ type: "DECREMENT" })}>Decrement</button>
            <button onClick={() => dispatch({ type: "ADD", payload: state.num })}>Add</button>
            <button onClick={() => dispatch({ type: "SUB", payload: state.num })}>SUB</button>
        </div>
    )
}

export default UseReduce
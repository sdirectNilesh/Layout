const initialState = {
    sugar: 50,
    rice: 20
}

const Reducer = (state = initialState, action) => {
    switch (action.type) {
        case "SET_SUGAR":
            return {...state, sugar:90}

        case "SELL_SUGAR":
            return { ...state, sugar: state.sugar - +action.payload }

        case "BUY_SUGAR":
            return { ...state, sugar: state.sugar + +action.payload }
        
        case "BUY_RICE":
            return { ...state, rice: state.rice + +action.payload}

        case "SELL_RICE":
            return { ...state, rice: state.rice - +action.payload}

        case "input":
            return { ...state, num: action.payload}

        default:
            return state;
    }
}

export default Reducer;
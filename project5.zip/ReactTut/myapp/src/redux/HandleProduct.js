import React from 'react'
import { useSelector, useDispatch } from 'react-redux'

function HandleProduct() {
    const dispatch = useDispatch();
    const state = useSelector((state) => state)

    const sellSugar = () => {
        dispatch({ type: "SELL_SUGAR", payload: state.num})
    }

    const setSugar = () => {
        dispatch({ type: "SET_SUGAR" })
    }

    const buySugar = () => {
        dispatch({ type: "BUY_SUGAR", payload: state.num})
    }

    const buyRice = () => {
        dispatch({ type: "BUY_RICE", payload: state.num})
    }
    
    const sellRice = () => {
        dispatch({ type: "SELL_RICE", payload: state.num})
    }

    return (
        <>
            <div>HandleProduct</div>
            <div>
                <p>Sugar:{state.sugar}</p>
                <p>Rice:{state.rice}</p>
                <input type="number" value={state.num} onChange = {(e) => dispatch({type: 'input', payload:e.target.value })} ></input>
                <button onClick={sellSugar}>SellSugar</button>
                <button onClick={buySugar}>BuySugar</button>
                <button onClick={buyRice}>BuyRice</button>
                <button onClick={sellRice}>SellRice</button>
            </div>
        </>
    )
}

export default HandleProduct
import './App.css';

import { render } from "react-dom";

import Home from './Pages/Home';


function App() {

  return (
    <>
      <Home />
    </>
  );
}

export default App;

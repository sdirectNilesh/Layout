const { sendOTP } = require("../services/twilio");


exports.sendMobileOTP = async (req, res) => {
    let phone = req.body.phone;
    let otp = Math.floor(100000 + Math.random() * 900000);

    let response = await sendOTP(phone, otp)
    res.json({ response:response })
}


const accountSid = 'ACe4da45c819a743887dd65b57dff65c5a';
const authToken = 'f3f01b3478a004ad8afe25b49d034ceb';
const client = require('twilio')(accountSid, authToken);

const sendOTP = async (phone,otp) => {
    const response = await client.messages
        .create({ body: `Your otp is ${otp}`, from: '+18147476855',  to: '+918586037839' })
    return response;
}

module.exports={
    sendOTP
}
const express = require("express");
const server = express();
// require("./db/database") // sirf hame require karna hai .. so that ki file ko le paye
const bodyParser = require('body-parser'); 
const authRoutes = require("./routes/auth")
// const client =require('twilio') ('AC17a96f0f88c8c2e5e43658f60f5b6ee9', '0fe245035c24fe9286ba3f8881c18e5b');


const cors = require('cors');
const { appendFile } = require("fs");

server.use('/auth', authRoutes)


server.use(bodyParser.urlencoded({ extended: false }));
server.use(bodyParser.json())

server.use(express.urlencoded({ extended: false }));

server.use("/uploads", express.static("uploads"))


// const getUsers = require("./Controllers/controller1");
PORT = 4000;


server.get('/',(req,res)=>{
    res.send(`
        Welcome to my account
        <h1>your message has been sent successfully</h1>
        ` )
})



server.use(require('./routes/auth'))


server.listen(PORT, () =>
    console.log('Example app listening on port'+PORT),
  );



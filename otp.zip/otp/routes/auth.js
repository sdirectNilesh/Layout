const express=require('express');
const router=express.Router();
const {sendMobileOTP,verifyMobileOTP} = require('../controllers/auth')

router.post("/send-otp", sendMobileOTP);

module.exports=router;
const userModel = require('../Models/userModel');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const nodemailer = require('nodemailer');




exports.signup = async (req, res) => {
    console.log(req.body);
    const salt = await bcrypt.genSalt(10);
    var usr = {
        name: req.body.name,
        email: req.body.email,
        password: await bcrypt.hash(req.body.password, salt)
    };
    created_user = await userModel.create(usr);
    res.status(201).json({ success: true, created_user, message: "Registration successful" });
}


exports.signin = async (req, res) => {
    // console.log(req.body);
    const userRes = await userModel.findOne({ where: { email: req.body.email } })
    if (!userRes) {
        res.status(400).json({ error: 'Invalid email' })
        return;
    }
    else {
        const isPasswordVerified = bcrypt.compareSync(req.body.password, userRes.password);
        if (isPasswordVerified) {
            const token = jwt.sign({ userId: userRes.id, email: userRes.email }, "secrete", { expiresIn: "1h" });
            res.status(200).json({ success: true, userdata: userRes, token, message: "Login successfully!" })
        } else {
            res.status(400).json({ error: 'Invalid Password' })
            return;
        }

    }
}

exports.reset = async(req, res) =>{
    const {email} = req.body
    console.log("req.body", req.body)

    try {
        const user = await userModel.findOne({where: {email}})
        console.log("user", user)

        const token = `${Math.floor(Math.random()*90000)}`;
        const link = `http://localhost:5001/reset/${token}`

        const transporter = nodemailer.createTransport({
            service: 'gmail',
            auth: {
                user: 'sdirectnilesh@gmail.com',
                pass: 'qqmueyngzjuqpaba',
            },
        });
        const mailOptions = {
            from: 'sdirectnilesh@gmail.com', 
              to: email, 
            subject: 'Your Generated Password', 
            text: link,
        };
         transporter.sendMail(mailOptions, (error, info) => {
            if (error) {
                console.error('Error sending email:', error);
            } else {
                console.log('Email sent:', info.response);
            }
        });

        return res.status(200).json({ success:true, msg:" check your mail id", user: user })

    } catch (error) {
        return res.status(500).json({ error: error.message })
    }
}

exports.updatereset = async(req, res) =>{
    
}
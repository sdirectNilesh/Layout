const app = require('express')();
const router =  require("./routes/route")

const server = require('http').createServer(app);

const { Server } = require("socket.io");

const cors = require('cors');
const bodyParser = require('body-parser');


app.use(cors());


app.use(bodyParser.urlencoded({ extended: false }))

app.use(bodyParser.json())

app.use("/",router);

const io = new Server(server, {
  cors: {
    origin: ["http://localhost:3000","http://localhost:3001"],
  }
});



io.on('connection', (socket) => {
  console.log('a user connected: ', socket.id);
  
  
  socket.on("join_room", (data) => {
    socket.join(data);
    console.log(`user connected with id: ${socket.id} with room id: ${data}`);
  })

  socket.on("send_message", (data) => {
    socket.to(data.room).emit("recieve_message", data)
  })

  socket.on("disconnect", () => {
    console.log('user disconnected: ', socket.id)
  })
});

server.listen(3002, () => {
  console.log('listening on *:3002');
});
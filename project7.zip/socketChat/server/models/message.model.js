const { Sequelize, DataTypes } = require('sequelize');
const sequelize = require("../database/db");



const MessageUserModel = sequelize.define('Nilchat_msgUserModel', {
    // Model attributes are defined here
    contents: {
        type: DataTypes.STRING
    }
});


module.exports = MessageUserModel;
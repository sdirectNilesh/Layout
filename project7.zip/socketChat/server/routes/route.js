const router = require('express').Router();


// message sending
const {
    sendMsg, findAllMsg
} = require("../controllers/message.controller");

router.post("/sendMessage", sendMsg);

router.get("/messages", findAllMsg);


module.exports = router;
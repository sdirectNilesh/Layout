const MessageUserModel = require("../models/message.model");


exports.sendMsg =  async(req, res) => {
  try {

    const newMessage = await MessageUserModel.create(req.body);
    console.log(req.body);
    return res.status(200).json({newMessage})
    console.log(newMessage)
  } catch (error) {
    console.log(error);
  }
};



exports.findAllMsg = async (req, res) => {
  
  try {
    const messages = await MessageUserModel.findAll();

    console.log("first", messages)
    return res.status(200).json({ success: true, messages });
  } catch (error) {
    console.log(error);
  }
};
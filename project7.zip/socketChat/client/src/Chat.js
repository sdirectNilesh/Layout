import React, { useEffect, useState } from 'react'
import ScrollToBottom from 'react-scroll-to-bottom';
import axios from "axios";


export const Chat = ({ socket, name, room }) => {
  const [message, setMessage] = useState([]);
  const [contents, setContents] = useState("");

  const sendMessage = async() => {
    if (contents !== "") {
      const messageData = {
        room: room,
        user: name,
        contents: contents
      };
      const response = await axios.post("http://localhost:3002/sendMessage", {contents});
      console.log(response);
      socket.emit("send_message", messageData);
      setMessage((previosmessagelist) => [...previosmessagelist, messageData])
      setContents("");
      console.log("contents: ", contents)
      console.log("messageData", messageData)
      
    }
    
  }

  const getMessage = async () => {

    const { data } = await axios.get("http://localhost:3002/messages")
    const message = data.messages;
    setMessage(message);
    console.log(data)

  }

  useEffect(() => {
    getMessage();
    socket.on("recieve_message", (messageData) => {
      setMessage((previosmessagelist) => [...previosmessagelist, messageData])
      console.log("messageData from sender: ", messageData)
    })
  }, [socket])

  return (
    // hello
        // Live chat
    <div className='chat-window'>
      <div className='chat-header'>
        <p>Live Chat</p>
      </div>
      <div className='chat-body'>
        <ScrollToBottom className='message-container'>
        
          {
          message.map((messageContent) => {
            // console.log("messagelist: ", messageList);
            return (
              <div className='message' id={name === messageContent.user ? "you" : "other"}>
                <div>
                  <div className='message-content'>
                    <p>{messageContent.contents}</p>
                  </div>
                  <div className='message-meta'>
                    <p id='user'>{messageContent.user}</p>
                  </div>
                </div>
              </div>
            );
          })}
        </ScrollToBottom>
      </div>
      <div className='chat-footer'>
        <input type="text" value={contents} placeholder="message" onChange={(e) => { setContents(e.target.value) }}></input>
        <button onClick={sendMessage}>send</button>
      </div>
    </div>
  )
}




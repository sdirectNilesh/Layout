const { Sequelize } = require("sequelize")
const sequelize = require("../config/db")

const Nilprod_obj = sequelize.define('Nilprod_obj', {
    // Model attributes are defined here
    product1: {
        type: Sequelize.STRING,
        allowNull: false
    },
    product2: {
        type: Sequelize.STRING,
        allowNull: false
    },
    category: {
        type: Sequelize.STRING,
        allowNull: false
    }
})



module.exports = Nilprod_obj;
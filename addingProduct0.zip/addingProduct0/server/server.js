const express = require('express');
const app = express();
require('./config/db');
const cors = require('cors');
const bodyparser = require('body-parser');
const productRoutes = require("./router/auth")

const PORT = 4500;


app.use(bodyparser.urlencoded({ extended: true }))
app.use(bodyparser.json())
app.use(cors());
app.use("/", productRoutes);
app.listen(PORT, function (err) {
    if (err) console.log(err);
    console.log("Server listening on PORT", PORT);
});
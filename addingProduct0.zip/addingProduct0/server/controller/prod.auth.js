const Nilprod_obj = require('../models/productModel');
const { Sequelize, DataTypes } = require('sequelize');
const { Op } = require("sequelize");
const sequelize = require('../config/db');

exports.addProduct = async(req, res) => {
   
    const t = await sequelize.transaction();
    try {
        console.log(req.body);
    
        const prdt = {
            product1: req.body.product1,
            product2: req.body.product2,
            category: req.body.category
        };
        let created_product = await Nilprod_obj.create(prdt, {transaction:t});
        await t.commit();
        return res.status(201).json({product : created_product});
    } catch (error) {
        console.log(error);
        await t.rollback();
    }
}
exports.getProduct = async(req, res) => {
    try {
        console.log(req.body);
    
        const data  = await Nilprod_obj.findAndCountAll();
        return res.status(201).json({product : data});
    } catch (error) {
        console.log(error)
    }
}

exports.getSearch = async(req, res) =>{
    try {
        const {product1} = req.query;
        console.log(req.query);

        const results = await Nilprod_obj.findAll({
            where: {
                product1:{
                    [Op.like]:`%${product1}%`
                }
            }
        })
       return res.json({success: true, items: results})
    } catch (error) {
        
    }
}
const express = require('express');
const { addProduct, getProduct, getSearch } = require('../controller/prod.auth');
const router = express.Router();



router.post('/add-product', addProduct);
router.get('/get-product', getProduct);
router.get('/search-product', getSearch);


module.exports = router;
const { Op } = require("sequelize");
const sequelize = require("../config/db");
const CartProduct = require("../models/cart_product");
const Order = require("../models/order");
const OrderProduct = require("../models/order_product");
const Product = require("../models/product");

exports.createOrder = async (req, res) => {
  const { productId, totalPrice, cartId } = req.body;
  const _transaction = await sequelize.transaction();
  try {
    await CartProduct.destroy(
      { where: { cartId } },
      { transaction: _transaction }
    );

    const _findOrder = await Order.findOne(
      { where: { userId: req.user.id } },
      { transaction: _transaction }
    );

    if (_findOrder) {
      const _findProductInOrder = await OrderProduct.findOne({
        where: {
          [Op.and]: [{ orderId: _findOrder.id }, { productId }],
        },
      });

      if (_findProductInOrder) {
        return res
          .status(200)
          .json({
            success: false,
            msg: "This product is already in your order list.",
          });
      }

      let newArr = [];
      productId.forEach((_productId) => {
        let newObj = {
          productId: _productId,
          orderId: _findOrder.id,
          totalPrice,
        };

        newArr.push(newObj);
      });

      const orderedProducts = await OrderProduct.bulkCreate(newArr, {
        transaction: _transaction,
      });
      await _transaction.commit();

      return res.status(201).json({
        success: true,
        orderedProducts,
        msg: "Order placed successfully!",
      });
    }

    const newOrder = await Order.create(
      { userId: req.user.id },
      { transaction: _transaction }
    );

    let newArr = [];
    productId.forEach((_productId) => {
      let newObj = {
        productId: _productId,
        orderId: newOrder.id,
        totalPrice,
      };

      newArr.push(newObj);
    });

    const orderedProducts = await OrderProduct.bulkCreate(newArr, {
      transaction: _transaction,
    });
    await _transaction.commit();

    return res.status(201).json({
      success: true,
      orderedProducts,
      msg: "Order placed successfully!",
    });
  } catch (error) {
    await _transaction.rollback();
    console.log(error.message);
    return res.status(404).json({ msg: error.message });
  }
};

exports.getAllOrders = async (req, res) => {
  try {
    const findOrders = await Product.findAll({
      include: [
        {
          model: Order,
          where: {
            userId: req.user.id,
          },
        },
      ],
    });

    return res.status(200).json({ success: true, findOrders });
  } catch (error) {
    console.log(error.message);
    return res.status(404).json({ msg: error.message });
  }
};

exports.cancelOrder = async (req, res) => {
  const { productId, orderId } = req.query;
  try {
    await OrderProduct.destroy({
      where: { [Op.and]: [{ productId }, { orderId }] },
    });
    return res
      .status(200)
      .json({ success: true, msg: "Order cancelled successfully!" });
  } catch (error) {
    console.log(error.message);
    return res.status(404).json({ msg: error.message });
  }
};

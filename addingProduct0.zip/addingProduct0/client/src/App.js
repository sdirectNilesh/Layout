
import AddProd from './AddProd';
import './App.css';


function App() {
  return (
    <div className="App">
      <AddProd />
    </div>
  );
}

export default App;

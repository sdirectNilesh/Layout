import React, { useEffect, useState, useMemo } from 'react'
import { Col, Button, Row, Form, Card, Container } from "react-bootstrap"
import axios from 'axios'
import Table from 'react-bootstrap/Table';
import LoadingSpinner from "./Loader";
import Pagination from './Pagination';

let PageSize = 15;

function AddProd({ currentItems }) {
    const [product1, setProduct1] = useState('');
    const [product2, setProduct2] = useState('');
    const [category, setCategory] = useState('');
    const [products, setProducts] = useState([]);
    const [search, setSearch] = useState("");
    const [isLoading, setIsLoading] = useState(false);
    const [currentPage, setCurrentPage] = useState(1);


    const currentTableData = useMemo(() => {
        const firstPageIndex = (currentPage - 1) * PageSize;
        const lastPageIndex = firstPageIndex + PageSize;
        return products.slice(firstPageIndex, lastPageIndex);
      }, [currentPage]);

    const addProduct = async (e) => {
        e.preventDefault();
        setIsLoading(true);
        const res = axios
            .post('http://localhost:4500/add-product', {
                product1,
                product2,
                category
            })
            .then((response) => {
                console.log(response);
                fetchProducts();
                setIsLoading(false);
            }).catch(() =>{ console.log("err");
            setIsLoading(false);
        });
        setTimeout(()=>{
            setIsLoading(false);
        },5000)

    }
    const fetchProducts = async () => {
        const { data } = await axios.get(
            "http://localhost:4500/get-product/"
        );
        const products = data.product.rows;
        setProducts(products);
        console.log("list: ",data);
    };

    useEffect(() => {
        fetchProducts();
    }, []);

    // useEffect(() => {

    //     const searchItem = async () => {

    //         try {
    //             const res = await axios.get(`http://localhost:4500/search-product?product1=${search.toLowerCase()}`);
    //             console.log("searched item: ",res);
    //             // setProducts(res.data.product);
    //             setProducts(res.data.items);
    //             console.log("prod: ", products);
    //             console.log("product length=",products.length)
    //         } catch (error) {
    //             console.log(error)
    //         }

    //     }
    //     searchItem()

    // }, [search])


    return (
        <div>
             {currentItems &&
        currentItems.map((item) => (
          <div>
            <h3>Item #{item}</h3>
          </div>
        ))}
            
            <Form className="d-flex">
                <Form.Control
                    type="search"
                    placeholder="Search"
                    className="me-2"
                    aria-label="Search"
                    onChange={(e) => setSearch(e.target.value)} value={search}
                />
            </Form>
            <br></br>
            <Table class="table" >
                <thead>
                    <tr>
                        <th scope="col">Index</th>
                        <th scope="col">BRAND</th>
                        <th scope='col'>Price</th>
                        <th scope='col'>Category</th>
                    </tr>
                </thead>
                <tbody >
                    {products.length > 0 && products.map((item) => (
                        <tr>
                            <th scope="row">{item.id}</th>
                            <td>{item.product1}</td>
                            <td>{item.product2}</td>
                            <td>{item.category}</td>
                        </tr>
                    ))
                    }
                </tbody>
            </Table>
            <Pagination
        className="pagination-bar"
        currentPage={currentPage}
        totalCount={products.length}
        pageSize={PageSize}
        onPageChange={page => setCurrentPage(page)}
      />
            <Container>
                <Row className="vh-100 d-flex justify-content-center align-items-center">
                    <Col md={8} lg={6} xs={12}>
                        <div className="border border-3 border-primary"></div>
                        <Card className="shadow">
                            <Card.Body>
                                <div className="mb-3 mt-md-4">
                                    <h2 className="fw-bold mb-2 text-uppercase ">Add Product</h2>
                                    <div className="mb-3">
                                        <Form method='POST' onSubmit={addProduct} >
                                            <Form.Group className="mb-3" controlId="formBasicEmail">
                                                <Form.Label className="text-center" aria-required>
                                                    Product Name
                                                </Form.Label>
                                                <Form.Control type="text" placeholder="Product" value={product1} onChange={(e) => setProduct1(e.target.value)} required/>
                                            </Form.Group>

                                            <Form.Group
                                                className="mb-3"
                                                controlId="formBasicPassword"
                                            >
                                                <Form.Label aria-required>Product Price</Form.Label>
                                                <Form.Control type="text" placeholder="Price" value={product2} onChange={(e) => setProduct2(e.target.value)} required/>
                                            </Form.Group>
                                            <Form.Group as={Col} controlId="formGridState">
                                                <Form.Label>Category</Form.Label>
                                                <Form.Select defaultValue="Category" placeholder="Category" onChange={(e) => setCategory(e.target.value)} required>
                                                    <option>Electronics</option>
                                                    <option>IOS</option>
                                                    <option>Android</option>
                                                    <option>Beauty</option>
                                                </Form.Select>
                                            </Form.Group>
                                            <br></br>
                                            <div className="d-grid" mb-3>
                                            
                                                <Button variant="primary" type="submit" value="addProduct" >
                                                    Add
                                                </Button>
                                                {isLoading ? <LoadingSpinner /> : fetchProducts}
                                            </div>
                                        </Form>
                                    </div>
                                </div>
                            </Card.Body>
                        </Card>
                    </Col>
                </Row>
            </Container>
            <nav aria-label="Page navigation example">
  <ul class="pagination">
    <li class="page-item"><a class="page-link" href="#">Previous</a></li>
    <li class="page-item"><a class="page-link" href="#">1</a></li>
    <li class="page-item"><a class="page-link" href="#">2</a></li>
    <li class="page-item"><a class="page-link" href="#">3</a></li>
    <li class="page-item"><a class="page-link" href="#">Next</a></li>
  </ul>
</nav>

        </div>
    )
}

export default AddProd